<?php
require_once __DIR__ . '/../includes/config.php';
requireRole('student');
$user = getCurrentUser();
$db = getDB();

// Get student's lectures
$lectures = $db->prepare("
    SELECT l.*, u.full_name as teacher_name,
           ms.focus_percentage, ms.final_score, ms.id as session_id
    FROM lecture_students ls
    JOIN lectures l ON ls.lecture_id = l.id
    JOIN users u ON l.teacher_id = u.id
    LEFT JOIN monitoring_sessions ms ON ms.lecture_id = l.id AND ms.student_id = ?
    WHERE ls.student_id = ?
    ORDER BY l.created_at DESC
");
$lectures->execute([$user['id'], $user['id']]);
$lectures = $lectures->fetchAll();

// Overall stats
$overallStats = $db->prepare("
    SELECT AVG(focus_percentage) as avg_focus, COUNT(*) as total_sessions,
           SUM(total_frames) as total_frames, SUM(focused_frames) as focused_frames
    FROM monitoring_sessions WHERE student_id = ?
");
$overallStats->execute([$user['id']]);
$stats = $overallStats->fetch();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>لوحة الطالب — GazeTrack</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #0a0e1a; --sidebar: #0f1523; --card: #111827; --border: #1f2937;
    --accent: #6366f1; --accent2: #8b5cf6; --text: #f9fafb; --muted: #9ca3af;
    --success: #10b981; --warning: #f59e0b; --danger: #ef4444;
  }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Cairo', sans-serif; background: var(--bg); color: var(--text); display: flex; min-height: 100vh; }
  .sidebar {
    width: 240px; background: var(--sidebar); border-left: 1px solid var(--border);
    display: flex; flex-direction: column; padding: 1.5rem 1rem; position: fixed;
    height: 100vh; right: 0; z-index: 100;
  }
  .sidebar-logo { display: flex; align-items: center; gap: .7rem; padding: .5rem .7rem; margin-bottom: 2rem; }
  .sidebar-logo .icon { width: 36px; height: 36px; background: linear-gradient(135deg, var(--accent), var(--accent2)); border-radius: 10px; display: flex; align-items: center; justify-content: center; }
  .sidebar-logo span { font-weight: 900; font-size: 1.1rem; }
  .sidebar-logo span em { color: var(--accent); font-style: normal; }
  .nav-item { display: flex; align-items: center; gap: .7rem; padding: .65rem .8rem; border-radius: 10px; cursor: pointer; transition: all .2s; text-decoration: none; color: var(--muted); font-size: .88rem; margin-bottom: .2rem; }
  .nav-item:hover { background: rgba(255,255,255,.05); color: var(--text); }
  .nav-item.active { background: rgba(99,102,241,.15); color: var(--accent); font-weight: 600; }
  .sidebar-footer { margin-top: auto; border-top: 1px solid var(--border); padding-top: 1rem; }
  .user-info { display: flex; align-items: center; gap: .7rem; padding: .5rem .7rem; margin-bottom: .7rem; }
  .user-avatar { width: 34px; height: 34px; background: linear-gradient(135deg, var(--accent), var(--accent2)); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: .8rem; }
  .user-name { font-size: .83rem; font-weight: 600; }
  .user-role { font-size: .72rem; color: var(--muted); }
  .logout-btn { display: block; background: rgba(239,68,68,.1); border: 1px solid rgba(239,68,68,.2); color: #fca5a5; border-radius: 10px; padding: .55rem; text-align: center; text-decoration: none; font-size: .82rem; transition: background .2s; }
  .logout-btn:hover { background: rgba(239,68,68,.2); }
  .main { margin-right: 240px; flex: 1; padding: 2rem; }
  .page-header { margin-bottom: 2rem; }
  .page-header h1 { font-size: 1.5rem; font-weight: 900; }
  .page-header p { color: var(--muted); font-size: .88rem; }
  .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; margin-bottom: 2rem; }
  .stat-card { background: var(--card); border: 1px solid var(--border); border-radius: 14px; padding: 1.3rem; display: flex; align-items: center; gap: .9rem; }
  .stat-icon { width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.3rem; flex-shrink: 0; }
  .stat-icon.purple { background: rgba(99,102,241,.15); }
  .stat-icon.green { background: rgba(16,185,129,.15); }
  .stat-icon.blue { background: rgba(59,130,246,.15); }
  .stat-value { font-size: 1.7rem; font-weight: 900; }
  .stat-label { font-size: .78rem; color: var(--muted); }
  /* Join lecture */
  .join-box { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 1.5rem; margin-bottom: 2rem; }
  .join-box h3 { font-weight: 700; margin-bottom: 1rem; }
  .join-form { display: flex; gap: .7rem; align-items: center; }
  .join-input { flex: 1; background: rgba(255,255,255,.05); border: 1px solid var(--border); border-radius: 10px; padding: .7rem 1rem; color: var(--text); font-family: 'Cairo', sans-serif; font-size: .95rem; outline: none; direction: rtl; text-transform: uppercase; letter-spacing: .1em; max-width: 200px; }
  .join-input:focus { border-color: var(--accent); }
  .btn { padding: .65rem 1.3rem; border-radius: 10px; font-family: 'Cairo', sans-serif; font-size: .88rem; font-weight: 600; cursor: pointer; transition: all .2s; border: none; text-decoration: none; display: inline-flex; align-items: center; gap: .4rem; }
  .btn-primary { background: linear-gradient(135deg, var(--accent), var(--accent2)); color: white; }
  .btn-primary:hover { transform: translateY(-1px); }
  /* Lectures */
  .lectures-list { display: flex; flex-direction: column; gap: .9rem; }
  .lecture-item { background: var(--card); border: 1px solid var(--border); border-radius: 14px; padding: 1.2rem 1.5rem; display: flex; align-items: center; gap: 1.2rem; transition: border-color .2s; }
  .lecture-item:hover { border-color: rgba(99,102,241,.3); }
  .lecture-icon { width: 46px; height: 46px; background: rgba(99,102,241,.1); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.4rem; flex-shrink: 0; }
  .lecture-info { flex: 1; }
  .lecture-title { font-weight: 700; font-size: .95rem; }
  .lecture-meta { font-size: .78rem; color: var(--muted); margin-top: .2rem; }
  .score-badge { display: inline-flex; padding: .25rem .7rem; border-radius: 20px; font-size: .75rem; font-weight: 700; }
  .score-excellent { background: rgba(16,185,129,.15); color: #6ee7b7; }
  .score-good { background: rgba(59,130,246,.15); color: #93c5fd; }
  .score-average { background: rgba(245,158,11,.15); color: #fcd34d; }
  .score-poor { background: rgba(239,68,68,.15); color: #fca5a5; }
  .lecture-actions { display: flex; gap: .5rem; align-items: center; }
  .btn-sm { padding: .4rem .85rem; font-size: .78rem; }
  .btn-monitor { background: linear-gradient(135deg, var(--accent), var(--accent2)); color: white; }
  .status-active { background: rgba(16,185,129,.1); border-color: rgba(16,185,129,.3); }
</style>
</head>
<body>
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="icon">👁️</div>
    <span>Gaze<em>Track</em></span>
  </div>
  <nav>
    <a href="dashboard.php" class="nav-item active"><span>📊</span> لوحة التحكم</a>
    <a href="my_lectures.php" class="nav-item"><span>📚</span> محاضراتي</a>
    <a href="my_progress.php" class="nav-item"><span>📈</span> تقدمي</a>
    <a href="settings.php" class="nav-item"><span>⚙️</span> الإعدادات</a>
  </nav>
  <div class="sidebar-footer">
    <div class="user-info">
      <div class="user-avatar"><?= mb_substr($user['full_name'], 0, 1) ?></div>
      <div>
        <div class="user-name"><?= htmlspecialchars($user['full_name']) ?></div>
        <div class="user-role">طالب</div>
      </div>
    </div>
    <a href="../logout.php" class="logout-btn">تسجيل الخروج</a>
  </div>
</aside>

<main class="main">
  <div class="page-header">
    <h1>أهلاً، <?= htmlspecialchars(explode(' ', $user['full_name'])[0]) ?>! 👋</h1>
    <p>هنا نظرة عامة على تركيزك خلال المحاضرات</p>
  </div>

  <!-- Stats -->
  <div class="stats-grid">
    <div class="stat-card">
      <div class="stat-icon purple">📚</div>
      <div><div class="stat-value"><?= count($lectures) ?></div><div class="stat-label">محاضرات منضم فيها</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon green">🎯</div>
      <div><div class="stat-value"><?= round($stats['avg_focus'] ?? 0, 1) ?>%</div><div class="stat-label">متوسط التركيز الكلي</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon blue">📊</div>
      <div><div class="stat-value"><?= $stats['total_sessions'] ?? 0 ?></div><div class="stat-label">جلسات المراقبة</div></div>
    </div>
  </div>

  <!-- Join Lecture -->
  <div class="join-box">
    <h3>🔑 الانضمام لمحاضرة جديدة</h3>
    <form action="../api/join_lecture.php" method="POST">
      <div class="join-form">
        <input type="text" name="access_code" class="join-input" placeholder="كود المحاضرة" maxlength="10" required>
        <button type="submit" class="btn btn-primary">انضم الآن</button>
      </div>
    </form>
  </div>

  <!-- Lectures -->
  <h2 style="font-size:1.05rem;font-weight:700;margin-bottom:1rem">📚 محاضراتي</h2>
  <div class="lectures-list">
    <?php foreach ($lectures as $lec): ?>
    <div class="lecture-item <?= $lec['status'] === 'active' ? 'status-active' : '' ?>">
      <div class="lecture-icon"><?= $lec['status'] === 'active' ? '🔴' : '📖' ?></div>
      <div class="lecture-info">
        <div class="lecture-title"><?= htmlspecialchars($lec['title']) ?></div>
        <div class="lecture-meta">
          👨‍🏫 <?= htmlspecialchars($lec['teacher_name']) ?> •
          <?= $lec['subject'] ?? 'عام' ?> •
          <?= $lec['status'] === 'active' ? '🔴 نشطة الآن' : ($lec['status'] === 'scheduled' ? '🕐 مجدولة' : '✓ منتهية') ?>
        </div>
      </div>
      <?php if ($lec['final_score']): ?>
      <span class="score-badge score-<?= $lec['final_score'] ?>">
        <?= scoreLabel($lec['final_score']) ?> • <?= round($lec['focus_percentage'], 0) ?>%
      </span>
      <?php endif; ?>
      <div class="lecture-actions">
        <?php if ($lec['status'] === 'active'): ?>
        <a href="monitor.php?lecture_id=<?= $lec['id'] ?>" class="btn btn-sm btn-monitor">📷 ابدأ المراقبة</a>
        <?php else: ?>
        <a href="session_report.php?lecture_id=<?= $lec['id'] ?>" class="btn btn-sm" style="background:rgba(255,255,255,.06);color:var(--text);border:1px solid var(--border)">📊 التقرير</a>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if (empty($lectures)): ?>
    <div style="text-align:center;padding:3rem;color:var(--muted)">
      <div style="font-size:3rem;margin-bottom:1rem">📚</div>
      <div>لم تنضم لأي محاضرة بعد. استخدم كود المحاضرة للانضمام!</div>
    </div>
    <?php endif; ?>
  </div>
</main>
</body>
</html>