<?php
require_once __DIR__ . '/../includes/config.php';
requireRole('student');
$user = getCurrentUser();
$db   = getDB();

// All sessions for this student
$sessions = $db->prepare("
    SELECT ms.*, l.title AS lecture_title, l.subject
    FROM monitoring_sessions ms
    JOIN lectures l ON ms.lecture_id = l.id
    WHERE ms.student_id = ?
    ORDER BY ms.started_at DESC
");
$sessions->execute([$user['id']]);
$sessions = $sessions->fetchAll();

$avgFocus  = $sessions ? array_sum(array_column($sessions,'focus_percentage')) / count($sessions) : 0;
$bestFocus = $sessions ? max(array_column($sessions,'focus_percentage')) : 0;
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>تقدمي — GazeTrack</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
<style>
  :root{--bg:#0a0e1a;--card:#111827;--border:#1f2937;--accent:#6366f1;--text:#f9fafb;--muted:#9ca3af;--success:#10b981;--warning:#f59e0b;--danger:#ef4444;}
  *{margin:0;padding:0;box-sizing:border-box}
  body{font-family:'Cairo',sans-serif;background:var(--bg);color:var(--text);display:flex;min-height:100vh}
  /* Sidebar */
  .sidebar{width:240px;background:#0f1523;border-left:1px solid var(--border);display:flex;flex-direction:column;padding:1.5rem 1rem;position:fixed;height:100vh;right:0;z-index:100}
  .sidebar-logo{display:flex;align-items:center;gap:.7rem;padding:.5rem .7rem;margin-bottom:2rem}
  .sidebar-logo .icon{width:36px;height:36px;background:linear-gradient(135deg,var(--accent),#8b5cf6);border-radius:10px;display:flex;align-items:center;justify-content:center}
  .sidebar-logo span{font-weight:900;font-size:1.1rem}
  .sidebar-logo span em{color:var(--accent);font-style:normal}
  .nav-item{display:flex;align-items:center;gap:.7rem;padding:.65rem .8rem;border-radius:10px;text-decoration:none;color:var(--muted);font-size:.88rem;margin-bottom:.2rem;transition:all .2s}
  .nav-item:hover{background:rgba(255,255,255,.05);color:var(--text)}
  .nav-item.active{background:rgba(99,102,241,.15);color:var(--accent);font-weight:600}
  .sidebar-footer{margin-top:auto;border-top:1px solid var(--border);padding-top:1rem}
  .user-info{display:flex;align-items:center;gap:.7rem;padding:.5rem .7rem;margin-bottom:.7rem}
  .user-avatar{width:34px;height:34px;background:linear-gradient(135deg,var(--accent),#8b5cf6);border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.8rem}
  .user-name{font-size:.83rem;font-weight:600}
  .user-role{font-size:.72rem;color:var(--muted)}
  .logout-btn{display:block;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);color:#fca5a5;border-radius:10px;padding:.55rem;text-align:center;text-decoration:none;font-size:.82rem;transition:background .2s}
  .logout-btn:hover{background:rgba(239,68,68,.2)}
  /* Main */
  .main{margin-right:240px;flex:1;padding:2rem}
  h1{font-size:1.45rem;font-weight:900;margin-bottom:.3rem}
  .sub{color:var(--muted);font-size:.84rem;margin-bottom:2rem}
  .grid-4{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin-bottom:2rem}
  .ov{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:1.3rem;text-align:center}
  .ov-val{font-size:2rem;font-weight:900}
  .ov-lbl{font-size:.76rem;color:var(--muted);margin-top:.3rem}
  .grid-2{display:grid;grid-template-columns:1fr 1fr;gap:1.2rem;margin-bottom:2rem}
  .card{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:1.4rem}
  .card h3{font-size:.92rem;font-weight:700;margin-bottom:1.2rem;color:var(--muted)}
  canvas{max-height:220px}
  /* Table */
  .sessions-table{width:100%;border-collapse:collapse}
  .sessions-table th{font-size:.78rem;color:var(--muted);font-weight:600;text-align:right;padding:.7rem 1rem;border-bottom:1px solid var(--border)}
  .sessions-table td{padding:.85rem 1rem;border-bottom:1px solid rgba(255,255,255,.04);font-size:.84rem;vertical-align:middle}
  .sessions-table tr:last-child td{border-bottom:none}
  .bar-inline{display:flex;align-items:center;gap:.5rem}
  .bar{height:7px;background:rgba(255,255,255,.08);border-radius:4px;overflow:hidden;width:70px}
  .bar-fill{height:100%;border-radius:4px}
  .badge{display:inline-flex;padding:.2rem .6rem;border-radius:20px;font-size:.72rem;font-weight:700}
  .score-excellent{background:rgba(16,185,129,.15);color:#6ee7b7}
  .score-good{background:rgba(59,130,246,.15);color:#93c5fd}
  .score-average{background:rgba(245,158,11,.15);color:#fcd34d}
  .score-poor{background:rgba(239,68,68,.15);color:#fca5a5}
</style>
</head>
<body>
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="icon">👁️</div>
    <span>Gaze<em>Track</em></span>
  </div>
  <nav>
    <a href="dashboard.php" class="nav-item"><span>📊</span> لوحة التحكم</a>
    <a href="my_lectures.php" class="nav-item"><span>📚</span> محاضراتي</a>
    <a href="my_progress.php" class="nav-item active"><span>📈</span> تقدمي</a>
    <a href="settings.php" class="nav-item"><span>⚙️</span> الإعدادات</a>
  </nav>
  <div class="sidebar-footer">
    <div class="user-info">
      <div class="user-avatar"><?= mb_substr($user['full_name'],0,1) ?></div>
      <div>
        <div class="user-name"><?= htmlspecialchars($user['full_name']) ?></div>
        <div class="user-role">طالب</div>
      </div>
    </div>
    <a href="../logout.php" class="logout-btn">تسجيل الخروج</a>
  </div>
</aside>

<main class="main">
  <h1>📈 تقدمي عبر المحاضرات</h1>
  <div class="sub">نظرة شاملة على أدائك في كل الجلسات</div>

  <!-- KPIs -->
  <div class="grid-4">
    <div class="ov"><div class="ov-val"><?= count($sessions) ?></div><div class="ov-lbl">إجمالي الجلسات</div></div>
    <div class="ov"><div class="ov-val" style="color:var(--success)"><?= round($avgFocus,1) ?>%</div><div class="ov-lbl">متوسط التركيز</div></div>
    <div class="ov"><div class="ov-val" style="color:var(--accent)"><?= round($bestFocus,1) ?>%</div><div class="ov-lbl">أعلى نسبة تركيز</div></div>
    <div class="ov">
      <div class="ov-val"><?= count(array_filter($sessions,fn($s)=>$s['final_score']==='excellent')) ?></div>
      <div class="ov-lbl">جلسات ممتازة 🌟</div>
    </div>
  </div>

  <!-- Charts -->
  <div class="grid-2">
    <div class="card">
      <h3>📉 تطور التركيز عبر الجلسات</h3>
      <canvas id="progressChart"></canvas>
    </div>
    <div class="card">
      <h3>🍩 توزيع التقييمات</h3>
      <canvas id="scoreChart"></canvas>
    </div>
  </div>

  <!-- Sessions history table -->
  <div class="card">
    <h3 style="margin-bottom:1.2rem">📋 سجل الجلسات</h3>
    <table class="sessions-table">
      <thead>
        <tr><th>المحاضرة</th><th>التركيز</th><th>مركّز</th><th>متشتت</th><th>التقييم</th><th>التفاصيل</th></tr>
      </thead>
      <tbody>
        <?php foreach ($sessions as $s):
          $fp = round($s['focus_percentage'],1);
          $color = $fp>=70?'var(--success)':($fp>=40?'var(--warning)':'var(--danger)');
        ?>
        <tr>
          <td><strong><?= htmlspecialchars($s['lecture_title']) ?></strong><div style="font-size:.74rem;color:var(--muted)"><?= $s['subject']??'—' ?></div></td>
          <td>
            <div class="bar-inline">
              <div class="bar"><div class="bar-fill" style="width:<?= $fp ?>%;background:<?= $color ?>"></div></div>
              <span><?= $fp ?>%</span>
            </div>
          </td>
          <td style="color:var(--success)"><?= $s['focused_frames'] ?></td>
          <td style="color:var(--danger)"><?= $s['distracted_frames'] ?></td>
          <td><span class="badge score-<?= $s['final_score'] ?>"><?= scoreLabel($s['final_score']) ?></span></td>
          <td><a href="session_report.php?lecture_id=<?= $s['lecture_id'] ?>" style="color:var(--accent);text-decoration:none;font-size:.8rem">عرض التقرير ←</a></td>
        </tr>
        <?php endforeach; ?>
        <?php if(empty($sessions)): ?>
        <tr><td colspan="6" style="text-align:center;padding:3rem;color:var(--muted)">لا توجد جلسات بعد</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</main>

<script>
const sessions = <?= json_encode(array_reverse($sessions)) ?>;

// Progress Chart
const progressCtx = document.getElementById('progressChart').getContext('2d');
new Chart(progressCtx, {
  type: 'line',
  data: {
    labels: sessions.map((s,i) => s.lecture_title.substring(0,12) + (s.lecture_title.length>12?'…':'')),
    datasets: [{
      label: 'نسبة التركيز %',
      data: sessions.map(s => parseFloat(s.focus_percentage||0).toFixed(1)),
      borderColor: '#6366f1',
      backgroundColor: 'rgba(99,102,241,.15)',
      fill: true,
      tension: 0.4,
      pointBackgroundColor: '#6366f1',
      pointRadius: 5,
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      x: { ticks: { color: '#9ca3af', font: { family: 'Cairo', size: 11 } }, grid: { color: 'rgba(255,255,255,.05)' } },
      y: { min: 0, max: 100, ticks: { color: '#9ca3af', font: { family: 'Cairo' } }, grid: { color: 'rgba(255,255,255,.05)' } }
    }
  }
});

// Score Distribution
const counts = { excellent: 0, good: 0, average: 0, poor: 0 };
sessions.forEach(s => { if (counts[s.final_score] !== undefined) counts[s.final_score]++; });
const scoreCtx = document.getElementById('scoreChart').getContext('2d');
new Chart(scoreCtx, {
  type: 'doughnut',
  data: {
    labels: ['ممتاز', 'جيد', 'مقبول', 'ضعيف'],
    datasets: [{
      data: [counts.excellent, counts.good, counts.average, counts.poor],
      backgroundColor: ['#10b981','#3b82f6','#f59e0b','#ef4444'],
      borderWidth: 0,
      hoverOffset: 6,
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'right',
        labels: { color: '#9ca3af', font: { family: 'Cairo', size: 12 }, padding: 12 }
      }
    }
  }
});
</script>
</body>
</html>