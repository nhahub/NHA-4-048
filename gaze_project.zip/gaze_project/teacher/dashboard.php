<?php
require_once __DIR__ . '/../includes/config.php';
requireRole('teacher');
$user = getCurrentUser();
$db = getDB();

// Get teacher's lectures
$lectures = $db->prepare("
    SELECT l.*, 
           COUNT(DISTINCT ls.student_id) as enrolled_students,
           AVG(ms.focus_percentage) as avg_focus
    FROM lectures l
    LEFT JOIN lecture_students ls ON l.id = ls.lecture_id
    LEFT JOIN monitoring_sessions ms ON l.id = ms.lecture_id
    WHERE l.teacher_id = ?
    GROUP BY l.id
    ORDER BY l.created_at DESC
");
$lectures->execute([$user['id']]);
$lectures = $lectures->fetchAll();

// Stats
$totalStudents = $db->prepare("
    SELECT COUNT(DISTINCT ls.student_id) as cnt
    FROM lecture_students ls
    JOIN lectures l ON ls.lecture_id = l.id
    WHERE l.teacher_id = ?
");
$totalStudents->execute([$user['id']]);
$totalStudents = $totalStudents->fetchColumn() ?? 0;

$activeLectures = array_filter($lectures, fn($l) => $l['status'] === 'active');
$avgFocusAll = $db->prepare("
    SELECT AVG(ms.focus_percentage)
    FROM monitoring_sessions ms
    JOIN lectures l ON ms.lecture_id = l.id
    WHERE l.teacher_id = ?
");
$avgFocusAll->execute([$user['id']]);
$avgFocusAll = round($avgFocusAll->fetchColumn() ?? 0, 1);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>لوحة المدرس — GazeTrack</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #0a0e1a; --sidebar: #0f1523; --card: #111827; --border: #1f2937;
    --accent: #6366f1; --accent2: #8b5cf6; --text: #f9fafb; --muted: #9ca3af;
    --success: #10b981; --warning: #f59e0b; --danger: #ef4444; --info: #3b82f6;
  }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Cairo', sans-serif; background: var(--bg); color: var(--text); display: flex; min-height: 100vh; }
  /* Sidebar */
  .sidebar {
    width: 260px; background: var(--sidebar); border-left: 1px solid var(--border);
    display: flex; flex-direction: column; padding: 1.5rem 1rem; position: fixed;
    height: 100vh; right: 0; z-index: 100;
  }
  .sidebar-logo { display: flex; align-items: center; gap: .7rem; padding: .5rem .7rem; margin-bottom: 2rem; }
  .sidebar-logo .icon { width: 38px; height: 38px; background: linear-gradient(135deg, var(--accent), var(--accent2)); border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; }
  .sidebar-logo span { font-weight: 900; font-size: 1.2rem; }
  .sidebar-logo span em { color: var(--accent); font-style: normal; }
  .sidebar-nav { flex: 1; }
  .nav-section { font-size: .72rem; color: var(--muted); font-weight: 700; letter-spacing: .08em; padding: 0 .7rem; margin: 1rem 0 .5rem; text-transform: uppercase; }
  .nav-item {
    display: flex; align-items: center; gap: .7rem; padding: .7rem .8rem;
    border-radius: 10px; cursor: pointer; transition: all .2s;
    text-decoration: none; color: var(--muted); font-size: .9rem; margin-bottom: .2rem;
  }
  .nav-item:hover { background: rgba(255,255,255,.05); color: var(--text); }
  .nav-item.active { background: rgba(99,102,241,.15); color: var(--accent); font-weight: 600; }
  .nav-item .icon { font-size: 1.1rem; width: 22px; }
  .sidebar-footer { border-top: 1px solid var(--border); padding-top: 1rem; }
  .user-info { display: flex; align-items: center; gap: .7rem; padding: .6rem .7rem; }
  .user-avatar {
    width: 36px; height: 36px; background: linear-gradient(135deg, var(--accent), var(--accent2));
    border-radius: 50%; display: flex; align-items: center; justify-content: center;
    font-weight: 700; font-size: .85rem;
  }
  .user-name { font-size: .85rem; font-weight: 600; }
  .user-role { font-size: .75rem; color: var(--muted); }
  .logout-btn { display: block; width: 100%; background: rgba(239,68,68,.1); border: 1px solid rgba(239,68,68,.2); color: #fca5a5; border-radius: 10px; padding: .6rem; text-align: center; text-decoration: none; font-size: .85rem; font-family: 'Cairo', sans-serif; cursor: pointer; margin-top: .7rem; transition: background .2s; }
  .logout-btn:hover { background: rgba(239,68,68,.2); }
  /* Main */
  .main { margin-right: 260px; flex: 1; padding: 2rem; }
  .page-header { margin-bottom: 2rem; }
  .page-header h1 { font-size: 1.6rem; font-weight: 900; }
  .page-header p { color: var(--muted); font-size: .9rem; margin-top: .3rem; }
  /* Stats grid */
  .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; margin-bottom: 2rem; }
  .stat-card {
    background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 1.5rem;
    display: flex; align-items: center; gap: 1rem;
  }
  .stat-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.4rem; flex-shrink: 0; }
  .stat-icon.purple { background: rgba(99,102,241,.15); }
  .stat-icon.green { background: rgba(16,185,129,.15); }
  .stat-icon.blue { background: rgba(59,130,246,.15); }
  .stat-icon.orange { background: rgba(245,158,11,.15); }
  .stat-value { font-size: 1.8rem; font-weight: 900; line-height: 1; }
  .stat-label { font-size: .8rem; color: var(--muted); margin-top: .2rem; }
  /* Section */
  .section-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.2rem; }
  .section-header h2 { font-size: 1.1rem; font-weight: 700; }
  .btn { padding: .6rem 1.2rem; border-radius: 10px; font-family: 'Cairo', sans-serif; font-size: .85rem; font-weight: 600; cursor: pointer; transition: all .2s; border: none; text-decoration: none; display: inline-flex; align-items: center; gap: .4rem; }
  .btn-primary { background: linear-gradient(135deg, var(--accent), var(--accent2)); color: white; box-shadow: 0 4px 15px rgba(99,102,241,.3); }
  .btn-primary:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(99,102,241,.4); }
  .btn-sm { padding: .4rem .8rem; font-size: .78rem; }
  .btn-ghost { background: rgba(255,255,255,.05); color: var(--text); border: 1px solid var(--border); }
  .btn-ghost:hover { background: rgba(255,255,255,.1); }
  .btn-danger-ghost { background: rgba(239,68,68,.1); color: #fca5a5; border: 1px solid rgba(239,68,68,.2); }
  /* Lectures Table */
  .lectures-table { width: 100%; border-collapse: collapse; }
  .lectures-table th { font-size: .78rem; color: var(--muted); font-weight: 600; text-align: right; padding: .7rem 1rem; border-bottom: 1px solid var(--border); }
  .lectures-table td { padding: .9rem 1rem; border-bottom: 1px solid rgba(255,255,255,.04); font-size: .88rem; vertical-align: middle; }
  .lectures-table tr:last-child td { border-bottom: none; }
  .lectures-table tr:hover td { background: rgba(255,255,255,.02); }
  .status-badge {
    display: inline-flex; align-items: center; gap: .3rem;
    padding: .25rem .7rem; border-radius: 20px; font-size: .75rem; font-weight: 600;
  }
  .status-active { background: rgba(16,185,129,.15); color: #6ee7b7; }
  .status-scheduled { background: rgba(99,102,241,.15); color: #a5b4fc; }
  .status-ended { background: rgba(107,114,128,.15); color: #9ca3af; }
  .focus-bar-wrap { display: flex; align-items: center; gap: .6rem; }
  .focus-bar { flex: 1; height: 6px; background: rgba(255,255,255,.1); border-radius: 3px; overflow: hidden; }
  .focus-bar-fill { height: 100%; border-radius: 3px; transition: width .5s; }
  .actions { display: flex; gap: .4rem; }
  .card-box { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 1.5rem; }
  /* Modal */
  .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,.7); z-index: 1000; align-items: center; justify-content: center; backdrop-filter: blur(4px); }
  .modal-overlay.show { display: flex; }
  .modal { background: var(--card); border: 1px solid var(--border); border-radius: 20px; padding: 2rem; width: 100%; max-width: 480px; box-shadow: 0 25px 50px rgba(0,0,0,.6); }
  .modal h3 { font-size: 1.2rem; font-weight: 700; margin-bottom: 1.5rem; }
  .form-group { margin-bottom: 1.2rem; }
  label { display: block; font-size: .83rem; font-weight: 600; color: var(--muted); margin-bottom: .4rem; }
  input[type=text], input[type=datetime-local], textarea, select {
    width: 100%; background: rgba(255,255,255,.05); border: 1px solid var(--border);
    border-radius: 10px; padding: .7rem .9rem; color: var(--text);
    font-family: 'Cairo', sans-serif; font-size: .9rem; outline: none; direction: rtl;
    transition: border-color .2s;
  }
  input:focus, textarea:focus, select:focus { border-color: var(--accent); }
  textarea { resize: vertical; min-height: 80px; }
  .modal-actions { display: flex; gap: .7rem; margin-top: 1.5rem; justify-content: flex-end; }
  @media (max-width: 1024px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } }
</style>
</head>
<body>
<!-- Sidebar -->
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="icon">👁️</div>
    <span>Gaze<em>Track</em></span>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section">القائمة الرئيسية</div>
    <a href="dashboard.php" class="nav-item active"><span class="icon">📊</span> لوحة التحكم</a>
    <a href="lectures.php" class="nav-item"><span class="icon">📚</span> المحاضرات</a>
    <a href="students.php" class="nav-item"><span class="icon">👨‍🎓</span> الطلاب</a>
    <a href="reports.php" class="nav-item"><span class="icon">📈</span> التقارير</a>
    <div class="nav-section">الإعدادات</div>
    <a href="settings.php" class="nav-item"><span class="icon">⚙️</span> الإعدادات</a>
  </nav>
  <div class="sidebar-footer">
    <div class="user-info">
      <div class="user-avatar"><?= mb_substr($user['full_name'], 0, 1) ?></div>
      <div>
        <div class="user-name"><?= htmlspecialchars($user['full_name']) ?></div>
        <div class="user-role">مدرس</div>
      </div>
    </div>
    <a href="../logout.php" class="logout-btn">تسجيل الخروج</a>
  </div>
</aside>

<!-- Main -->
<main class="main">
  <div class="page-header">
    <h1>لوحة تحكم المدرس 🎓</h1>
    <p>أهلاً، <?= htmlspecialchars($user['full_name']) ?>! هنا نظرة عامة على كل حاجة.</p>
  </div>

  <!-- Stats -->
  <div class="stats-grid">
    <div class="stat-card">
      <div class="stat-icon purple">📚</div>
      <div><div class="stat-value"><?= count($lectures) ?></div><div class="stat-label">إجمالي المحاضرات</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon green">▶️</div>
      <div><div class="stat-value"><?= count($activeLectures) ?></div><div class="stat-label">محاضرات نشطة الآن</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon blue">👨‍🎓</div>
      <div><div class="stat-value"><?= $totalStudents ?></div><div class="stat-label">إجمالي الطلاب</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon orange">🎯</div>
      <div><div class="stat-value"><?= $avgFocusAll ?>%</div><div class="stat-label">متوسط التركيز الكلي</div></div>
    </div>
  </div>

  <!-- Lectures Table -->
  <div class="card-box">
    <div class="section-header">
      <h2>📚 محاضراتي</h2>
      <button class="btn btn-primary" onclick="document.getElementById('createModal').classList.add('show')">
        + إنشاء محاضرة
      </button>
    </div>
    <table class="lectures-table">
      <thead>
        <tr>
          <th>المحاضرة</th>
          <th>الكود</th>
          <th>الطلاب</th>
          <th>التركيز</th>
          <th>الحالة</th>
          <th>إجراءات</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($lectures as $lec): ?>
        <tr>
          <td>
            <strong><?= htmlspecialchars($lec['title']) ?></strong>
            <div style="font-size:.78rem;color:var(--muted)"><?= htmlspecialchars($lec['subject'] ?? '') ?></div>
          </td>
          <td><code style="background:rgba(99,102,241,.15);color:#a5b4fc;padding:.2rem .5rem;border-radius:6px;font-size:.85rem"><?= $lec['access_code'] ?></code></td>
          <td><?= $lec['enrolled_students'] ?></td>
          <td>
            <?php $fp = round($lec['avg_focus'] ?? 0, 1); ?>
            <div class="focus-bar-wrap">
              <div class="focus-bar">
                <div class="focus-bar-fill" style="width:<?= $fp ?>%;background:<?php
                  if ($fp >= 70) echo 'var(--success)';
                  elseif ($fp >= 40) echo 'var(--warning)';
                  else echo 'var(--danger)';
                ?>"></div>
              </div>
              <span style="font-size:.82rem;min-width:36px"><?= $fp ?>%</span>
            </div>
          </td>
          <td>
            <span class="status-badge status-<?= $lec['status'] ?>">
              <?= ['active'=>'● نشطة','scheduled'=>'○ مجدولة','ended'=>'✓ منتهية'][$lec['status']] ?>
            </span>
          </td>
          <td>
            <div class="actions">
              <a href="lecture_live.php?id=<?= $lec['id'] ?>" class="btn btn-sm btn-ghost">👁️ مراقبة</a>
              <a href="lecture_report.php?id=<?= $lec['id'] ?>" class="btn btn-sm btn-ghost">📊</a>
              <?php if ($lec['status'] === 'scheduled'): ?>
              <a href="start_lecture.php?id=<?= $lec['id'] ?>" class="btn btn-sm btn-primary">▶</a>
              <?php elseif ($lec['status'] === 'active'): ?>
              <a href="end_lecture.php?id=<?= $lec['id'] ?>" class="btn btn-sm btn-danger-ghost">■</a>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($lectures)): ?>
        <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:3rem">لا توجد محاضرات بعد. أنشئ أول محاضرة!</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</main>

<!-- Create Lecture Modal -->
<div class="modal-overlay" id="createModal">
  <div class="modal">
    <h3>📚 إنشاء محاضرة جديدة</h3>
    <form method="POST" action="create_lecture.php">
      <div class="form-group">
        <label>عنوان المحاضرة *</label>
        <input type="text" name="title" placeholder="مثال: مقدمة في الذكاء الاصطناعي" required>
      </div>
      <div class="form-group">
        <label>المادة</label>
        <input type="text" name="subject" placeholder="مثال: Computer Science">
      </div>
      <div class="form-group">
        <label>الوصف</label>
        <textarea name="description" placeholder="وصف مختصر للمحاضرة..."></textarea>
      </div>
      <div class="form-group">
        <label>الموعد المجدول (اختياري)</label>
        <input type="datetime-local" name="scheduled_at">
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-ghost" onclick="document.getElementById('createModal').classList.remove('show')">إلغاء</button>
        <button type="submit" class="btn btn-primary">✓ إنشاء المحاضرة</button>
      </div>
    </form>
  </div>
</div>

<script>
// Close modal on overlay click
document.getElementById('createModal').addEventListener('click', function(e) {
  if (e.target === this) this.classList.remove('show');
});
</script>
</body>
</html>