<?php
require_once __DIR__ . '/../includes/config.php';
requireRole('teacher');
$user = getCurrentUser();
$db   = getDB();

// All sessions across teacher's lectures
$sessions = $db->prepare("
    SELECT ms.*, l.title AS lecture_title, u.full_name AS student_name
    FROM monitoring_sessions ms
    JOIN lectures l ON ms.lecture_id = l.id
    JOIN users u ON ms.student_id = u.id
    WHERE l.teacher_id = ?
    ORDER BY ms.started_at DESC
    LIMIT 200
");
$sessions->execute([$user['id']]);
$sessions = $sessions->fetchAll();

// Per-lecture averages for chart
$lectureStats = $db->prepare("
    SELECT l.title, AVG(ms.focus_percentage) AS avg_fp,
           COUNT(DISTINCT ms.student_id) AS student_count
    FROM monitoring_sessions ms
    JOIN lectures l ON ms.lecture_id = l.id
    WHERE l.teacher_id = ?
    GROUP BY l.id
    ORDER BY l.created_at DESC
    LIMIT 10
");
$lectureStats->execute([$user['id']]);
$lectureStats = $lectureStats->fetchAll();

$overallAvg = $sessions ? array_sum(array_column($sessions,'focus_percentage')) / count($sessions) : 0;
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>التقارير — GazeTrack</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
<style>
  :root{--bg:#0a0e1a;--sidebar:#0f1523;--card:#111827;--border:#1f2937;--accent:#6366f1;--text:#f9fafb;--muted:#9ca3af;--success:#10b981;--warning:#f59e0b;--danger:#ef4444;}
  *{margin:0;padding:0;box-sizing:border-box}
  body{font-family:'Cairo',sans-serif;background:var(--bg);color:var(--text);display:flex;min-height:100vh}
  .sidebar{width:260px;background:var(--sidebar);border-left:1px solid var(--border);display:flex;flex-direction:column;padding:1.5rem 1rem;position:fixed;height:100vh;right:0;z-index:100}
  .sidebar-logo{display:flex;align-items:center;gap:.7rem;padding:.5rem .7rem;margin-bottom:2rem}
  .sidebar-logo .icon{width:38px;height:38px;background:linear-gradient(135deg,var(--accent),#8b5cf6);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.1rem}
  .sidebar-logo span{font-weight:900;font-size:1.2rem}
  .sidebar-logo span em{color:var(--accent);font-style:normal}
  .nav-item{display:flex;align-items:center;gap:.7rem;padding:.7rem .8rem;border-radius:10px;cursor:pointer;transition:all .2s;text-decoration:none;color:var(--muted);font-size:.9rem;margin-bottom:.2rem}
  .nav-item:hover{background:rgba(255,255,255,.05);color:var(--text)}
  .nav-item.active{background:rgba(99,102,241,.15);color:var(--accent);font-weight:600}
  .nav-item .icon{font-size:1.1rem;width:22px}
  .sidebar-footer{border-top:1px solid var(--border);padding-top:1rem;margin-top:auto}
  .user-info{display:flex;align-items:center;gap:.7rem;padding:.6rem .7rem}
  .user-avatar{width:36px;height:36px;background:linear-gradient(135deg,var(--accent),#8b5cf6);border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.85rem}
  .user-name{font-size:.85rem;font-weight:600}
  .user-role{font-size:.75rem;color:var(--muted)}
  .logout-btn{display:block;width:100%;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);color:#fca5a5;border-radius:10px;padding:.6rem;text-align:center;text-decoration:none;font-size:.85rem;font-family:'Cairo',sans-serif;cursor:pointer;margin-top:.7rem;transition:background .2s}
  .logout-btn:hover{background:rgba(239,68,68,.2)}
  .main{margin-right:260px;flex:1;padding:2rem}
  h1{font-size:1.5rem;font-weight:900;margin-bottom:.3rem}
  .sub{color:var(--muted);font-size:.84rem;margin-bottom:2rem}
  .grid-4{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin-bottom:2rem}
  .ov{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:1.3rem;text-align:center}
  .ov-val{font-size:2rem;font-weight:900}
  .ov-lbl{font-size:.76rem;color:var(--muted);margin-top:.3rem}
  .grid-2{display:grid;grid-template-columns:1fr 1fr;gap:1.2rem;margin-bottom:2rem}
  .card{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:1.4rem}
  .card h3{font-size:.92rem;font-weight:700;margin-bottom:1.2rem;color:var(--muted)}
  canvas{max-height:240px}
  table{width:100%;border-collapse:collapse}
  th{font-size:.78rem;color:var(--muted);font-weight:600;text-align:right;padding:.7rem 1rem;border-bottom:1px solid var(--border)}
  td{padding:.85rem 1rem;border-bottom:1px solid rgba(255,255,255,.04);font-size:.84rem;vertical-align:middle}
  tr:last-child td{border-bottom:none}
  .bar-inline{display:flex;align-items:center;gap:.5rem}
  .bar{height:7px;background:rgba(255,255,255,.08);border-radius:4px;overflow:hidden;width:80px}
  .bar-fill{height:100%;border-radius:4px}
  .badge{display:inline-flex;padding:.2rem .6rem;border-radius:20px;font-size:.72rem;font-weight:700}
  .score-excellent{background:rgba(16,185,129,.15);color:#6ee7b7}
  .score-good{background:rgba(59,130,246,.15);color:#93c5fd}
  .score-average{background:rgba(245,158,11,.15);color:#fcd34d}
  .score-poor{background:rgba(239,68,68,.15);color:#fca5a5}
</style>
</head>
<body>
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="icon">👁️</div>
    <span>Gaze<em>Track</em></span>
  </div>
  <nav class="sidebar-nav">
    <div style="font-size:.72rem;color:var(--muted);font-weight:700;letter-spacing:.08em;padding:0 .7rem;margin:1rem 0 .5rem;text-transform:uppercase">القائمة</div>
    <a href="dashboard.php" class="nav-item"><span class="icon">📊</span> لوحة التحكم</a>
    <a href="lectures.php" class="nav-item"><span class="icon">📚</span> المحاضرات</a>
    <a href="students.php" class="nav-item"><span class="icon">👨‍🎓</span> الطلاب</a>
    <a href="reports.php" class="nav-item active"><span class="icon">📈</span> التقارير</a>
    <a href="settings.php" class="nav-item"><span class="icon">⚙️</span> الإعدادات</a>
  </nav>
  <div class="sidebar-footer">
    <div class="user-info">
      <div class="user-avatar"><?= mb_substr($user['full_name'],0,1) ?></div>
      <div><div class="user-name"><?= htmlspecialchars($user['full_name']) ?></div><div class="user-role">مدرس</div></div>
    </div>
    <a href="../logout.php" class="logout-btn">تسجيل الخروج</a>
  </div>
</aside>

<main class="main">
  <h1>📈 التقارير الشاملة</h1>
  <div class="sub">تحليل أداء الطلاب عبر كل محاضراتك</div>

  <div class="grid-4">
    <div class="ov"><div class="ov-val"><?= count($sessions) ?></div><div class="ov-lbl">إجمالي الجلسات</div></div>
    <div class="ov"><div class="ov-val" style="color:var(--success)"><?= round($overallAvg,1) ?>%</div><div class="ov-lbl">متوسط التركيز الكلي</div></div>
    <div class="ov"><div class="ov-val" style="color:var(--success)"><?= count(array_filter($sessions,fn($s)=>$s['final_score']==='excellent')) ?></div><div class="ov-lbl">جلسات ممتازة</div></div>
    <div class="ov"><div class="ov-val" style="color:var(--danger)"><?= count(array_filter($sessions,fn($s)=>$s['final_score']==='poor')) ?></div><div class="ov-lbl">جلسات ضعيفة</div></div>
  </div>

  <div class="grid-2">
    <div class="card">
      <h3>📊 متوسط التركيز لكل محاضرة</h3>
      <canvas id="lectureChart"></canvas>
    </div>
    <div class="card">
      <h3>🍩 توزيع تقييمات الطلاب</h3>
      <canvas id="scoreChart"></canvas>
    </div>
  </div>

  <div class="card">
    <h3 style="margin-bottom:1.2rem">📋 سجل جلسات الطلاب</h3>
    <table>
      <thead>
        <tr><th>الطالب</th><th>المحاضرة</th><th>التركيز</th><th>مركّز</th><th>متشتت</th><th>التقييم</th></tr>
      </thead>
      <tbody>
        <?php foreach ($sessions as $s):
          $fp = round($s['focus_percentage'],1);
          $color = $fp>=70?'var(--success)':($fp>=40?'var(--warning)':'var(--danger)');
        ?>
        <tr>
          <td><strong><?= htmlspecialchars($s['student_name']) ?></strong></td>
          <td style="color:var(--muted);font-size:.8rem"><?= htmlspecialchars(mb_strimwidth($s['lecture_title'],0,30,'…')) ?></td>
          <td>
            <div class="bar-inline">
              <div class="bar"><div class="bar-fill" style="width:<?= $fp ?>%;background:<?= $color ?>"></div></div>
              <span><?= $fp ?>%</span>
            </div>
          </td>
          <td style="color:var(--success)"><?= $s['focused_frames'] ?></td>
          <td style="color:var(--danger)"><?= $s['distracted_frames'] ?></td>
          <td><span class="badge score-<?= $s['final_score'] ?>"><?= scoreLabel($s['final_score']) ?></span></td>
        </tr>
        <?php endforeach; ?>
        <?php if(empty($sessions)): ?>
        <tr><td colspan="6" style="text-align:center;padding:3rem;color:var(--muted)">لا توجد بيانات بعد</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</main>

<script>
const lectureStats = <?= json_encode(array_reverse($lectureStats)) ?>;
const sessions = <?= json_encode($sessions) ?>;

// Lecture bar chart
const lCtx = document.getElementById('lectureChart').getContext('2d');
new Chart(lCtx, {
  type: 'bar',
  data: {
    labels: lectureStats.map(l => l.title.substring(0,15) + (l.title.length>15?'…':'')),
    datasets: [{
      label: 'متوسط التركيز %',
      data: lectureStats.map(l => parseFloat(l.avg_fp||0).toFixed(1)),
      backgroundColor: lectureStats.map(l => {
        const v = parseFloat(l.avg_fp||0);
        return v>=70 ? 'rgba(16,185,129,.7)' : v>=40 ? 'rgba(245,158,11,.7)' : 'rgba(239,68,68,.7)';
      }),
      borderRadius: 8,
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      x: { ticks: { color: '#9ca3af', font: { family: 'Cairo', size: 11 } }, grid: { display: false } },
      y: { min: 0, max: 100, ticks: { color: '#9ca3af', font: { family: 'Cairo' } }, grid: { color: 'rgba(255,255,255,.05)' } }
    }
  }
});

// Score donut
const counts = { excellent: 0, good: 0, average: 0, poor: 0 };
sessions.forEach(s => { if (counts[s.final_score] !== undefined) counts[s.final_score]++; });
const sCtx = document.getElementById('scoreChart').getContext('2d');
new Chart(sCtx, {
  type: 'doughnut',
  data: {
    labels: ['ممتاز', 'جيد', 'مقبول', 'ضعيف'],
    datasets: [{ data: [counts.excellent, counts.good, counts.average, counts.poor],
      backgroundColor: ['#10b981','#3b82f6','#f59e0b','#ef4444'], borderWidth: 0, hoverOffset: 6 }]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { position: 'right', labels: { color: '#9ca3af', font: { family: 'Cairo', size: 12 }, padding: 12 } } }
  }
});
</script>
</body>
</html>