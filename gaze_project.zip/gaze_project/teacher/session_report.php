<?php
require_once __DIR__ . '/../includes/config.php';
requireRole('student');
$user = getCurrentUser();
$db   = getDB();

$lectureId = intval($_GET['lecture_id'] ?? 0);

$lecture = $db->prepare("
    SELECT l.*, u.full_name AS teacher_name
    FROM lectures l
    JOIN lecture_students ls ON l.id = ls.lecture_id
    JOIN users u ON l.teacher_id = u.id
    WHERE l.id = ? AND ls.student_id = ?
");
$lecture->execute([$lectureId, $user['id']]);
$lecture = $lecture->fetch();
if (!$lecture) { header('Location: dashboard.php'); exit; }

$session = $db->prepare("SELECT * FROM monitoring_sessions WHERE lecture_id = ? AND student_id = ?");
$session->execute([$lectureId, $user['id']]);
$session = $session->fetch();

// Timeline: last 80 events
$events = $db->prepare("
    SELECT is_focused, face_detected, confidence, recorded_at
    FROM gaze_events
    WHERE session_id = ?
    ORDER BY recorded_at ASC
    LIMIT 80
");
$events->execute([$session['id'] ?? 0]);
$events = $events->fetchAll();

$fp   = round($session['focus_percentage'] ?? 0, 1);
$score = $session['final_score'] ?? 'average';
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>تقرير جلستي — GazeTrack</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap" rel="stylesheet">
<style>
  :root{--bg:#0a0e1a;--card:#111827;--border:#1f2937;--accent:#6366f1;--text:#f9fafb;--muted:#9ca3af;--success:#10b981;--warning:#f59e0b;--danger:#ef4444;}
  *{margin:0;padding:0;box-sizing:border-box}
  body{font-family:'Cairo',sans-serif;background:var(--bg);color:var(--text);padding:2rem;min-height:100vh}
  .topbar{display:flex;align-items:center;gap:1rem;margin-bottom:2rem}
  .back{background:rgba(255,255,255,.07);border:1px solid var(--border);color:var(--text);padding:.45rem .9rem;border-radius:9px;text-decoration:none;font-size:.82rem}
  h1{font-size:1.45rem;font-weight:900}
  .sub{color:var(--muted);font-size:.84rem;margin-top:.2rem}
  .grid-4{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin-bottom:1.8rem}
  .ov-card{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:1.3rem;text-align:center}
  .ov-val{font-size:2rem;font-weight:900;line-height:1}
  .ov-lbl{font-size:.76rem;color:var(--muted);margin-top:.3rem}
  .grid-2{display:grid;grid-template-columns:1fr 1fr;gap:1.2rem;margin-bottom:1.8rem}
  .card{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:1.4rem}
  .card h3{font-size:.92rem;font-weight:700;margin-bottom:1.2rem;color:var(--muted)}
  /* Score card */
  .score-hero{display:flex;align-items:center;gap:1.4rem}
  .score-emoji-big{font-size:3.5rem;line-height:1}
  .score-name{font-size:1.8rem;font-weight:900}
  .score-desc{font-size:.84rem;color:var(--muted);margin-top:.3rem;line-height:1.6}
  .score-bar-wrap{margin-top:1rem}
  .score-bar-label{display:flex;justify-content:space-between;font-size:.78rem;color:var(--muted);margin-bottom:.4rem}
  .score-bar{height:10px;background:rgba(255,255,255,.08);border-radius:5px;overflow:hidden}
  .score-bar-fill{height:100%;border-radius:5px;transition:width 1.2s}
  /* Ring */
  .ring-wrap{display:flex;flex-direction:column;align-items:center;gap:1rem}
  .ring-svg{width:130px;height:130px}
  .ring-legend{display:flex;flex-direction:column;gap:.5rem;width:100%}
  .leg-row{display:flex;justify-content:space-between;font-size:.82rem;align-items:center}
  .leg-dot{width:10px;height:10px;border-radius:50%;display:inline-block;margin-left:.4rem}
  /* Timeline */
  .tl-wrap{display:flex;flex-wrap:wrap;gap:4px}
  .tl-block{width:18px;height:18px;border-radius:4px;background:rgba(255,255,255,.07)}
  .tl-block.f{background:var(--success)}
  .tl-block.d{background:var(--danger)}
  .tl-block.n{background:var(--warning)}
  .tl-legend{display:flex;gap:1.2rem;margin-top:.8rem;font-size:.74rem;color:var(--muted)}
  /* Compare bars */
  .compare-row{margin-bottom:.9rem}
  .cmp-header{display:flex;justify-content:space-between;font-size:.82rem;margin-bottom:.35rem}
  .cmp-bar{height:8px;background:rgba(255,255,255,.08);border-radius:4px;overflow:hidden}
  .cmp-fill{height:100%;border-radius:4px;background:var(--accent)}
  /* Advice */
  .advice-list{display:flex;flex-direction:column;gap:.7rem}
  .advice-item{display:flex;align-items:flex-start;gap:.7rem;padding:.8rem 1rem;background:rgba(255,255,255,.04);border-radius:10px;font-size:.84rem;line-height:1.55}
  .advice-icon{font-size:1.1rem;flex-shrink:0;margin-top:.05rem}
  @media(max-width:900px){.grid-4,.grid-2{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="topbar">
  <a href="dashboard.php" class="back">← لوحة التحكم</a>
  <div>
    <h1>📊 تقرير جلستي</h1>
    <div class="sub"><?= htmlspecialchars($lecture['title']) ?> — <?= htmlspecialchars($lecture['teacher_name']) ?></div>
  </div>
</div>

<?php if (!$session): ?>
<div style="text-align:center;padding:4rem;color:var(--muted)">
  <div style="font-size:3rem;margin-bottom:1rem">📭</div>
  <div>لا توجد بيانات مراقبة لهذه المحاضرة بعد.</div>
</div>
<?php else:
  $scoreData = [
    'excellent' => ['🌟','ممتاز','أداءٌ استثنائي! ركّزت معظم وقت المحاضرة.'],
    'good'      => ['👍','جيد',  'أداءٌ جيد، مع بعض لحظات التشتيت.'],
    'average'   => ['😐','مقبول','تركيزك متوسط — حاول تقليل المشتتات.'],
    'poor'      => ['😟','ضعيف', 'تركيزك كان منخفضاً. اتواصل مع دكتورك.'],
  ];
  [$emoji,$label,$desc] = $scoreData[$score] ?? $scoreData['average'];
  $barColor = $fp>=70?'var(--success)':($fp>=40?'var(--warning)':'var(--danger)');
?>

<!-- KPIs -->
<div class="grid-4">
  <div class="ov-card">
    <div class="ov-val" style="color:<?= $barColor ?>"><?= $fp ?>%</div>
    <div class="ov-lbl">نسبة التركيز</div>
  </div>
  <div class="ov-card">
    <div class="ov-val" style="color:var(--success)"><?= $session['focused_frames'] ?></div>
    <div class="ov-lbl">لحظات تركيز</div>
  </div>
  <div class="ov-card">
    <div class="ov-val" style="color:var(--danger)"><?= $session['distracted_frames'] ?></div>
    <div class="ov-lbl">لحظات تشتيت</div>
  </div>
  <div class="ov-card">
    <div class="ov-val"><?= $session['total_frames'] ?></div>
    <div class="ov-lbl">إجمالي القراءات</div>
  </div>
</div>

<!-- Score + Ring -->
<div class="grid-2">
  <div class="card">
    <h3>🏆 التقييم النهائي</h3>
    <div class="score-hero">
      <div class="score-emoji-big"><?= $emoji ?></div>
      <div>
        <div class="score-name"><?= $label ?></div>
        <div class="score-desc"><?= $desc ?></div>
      </div>
    </div>
    <div class="score-bar-wrap">
      <div class="score-bar-label"><span>نسبة التركيز</span><span><?= $fp ?>%</span></div>
      <div class="score-bar">
        <div class="score-bar-fill" style="width:<?= $fp ?>%;background:<?= $barColor ?>"></div>
      </div>
    </div>
  </div>

  <div class="card">
    <h3>🍩 توزيع الوقت</h3>
    <div class="ring-wrap">
      <?php
        $total = max(1, $session['total_frames']);
        $fPct  = round($session['focused_frames']/$total*100,1);
        $dPct  = round($session['distracted_frames']/$total*100,1);
        $nPct  = round($session['no_face_frames']/$total*100,1);
        $circumference = 251.2;
        $fOffset = $circumference - ($fPct/100)*$circumference;
      ?>
      <svg class="ring-svg" viewBox="0 0 100 100">
        <circle cx="50" cy="50" r="40" fill="none" stroke="rgba(255,255,255,.08)" stroke-width="14"/>
        <circle cx="50" cy="50" r="40" fill="none" stroke="var(--success)" stroke-width="14"
          stroke-dasharray="<?= $circumference ?>" stroke-dashoffset="<?= $fOffset ?>"
          stroke-linecap="round" transform="rotate(-90 50 50)"/>
        <text x="50" y="46" text-anchor="middle" fill="white" font-family="Cairo" font-size="15" font-weight="900"><?= $fPct ?>%</text>
        <text x="50" y="60" text-anchor="middle" fill="#9ca3af" font-family="Cairo" font-size="8">تركيز</text>
      </svg>
      <div class="ring-legend">
        <div class="leg-row"><span><span class="leg-dot" style="background:var(--success)"></span>مركّز</span><strong><?= $fPct ?>%</strong></div>
        <div class="leg-row"><span><span class="leg-dot" style="background:var(--danger)"></span>غير مركّز</span><strong><?= $dPct ?>%</strong></div>
        <div class="leg-row"><span><span class="leg-dot" style="background:var(--warning)"></span>لا وجه</span><strong><?= $nPct ?>%</strong></div>
      </div>
    </div>
  </div>
</div>

<!-- Timeline + Advice -->
<div class="grid-2">
  <div class="card">
    <h3>📅 خط زمني للتركيز</h3>
    <div class="tl-wrap">
      <?php foreach ($events as $e):
        $cls = !$e['face_detected'] ? 'n' : ($e['is_focused'] ? 'f' : 'd');
      ?>
      <div class="tl-block <?= $cls ?>" title="<?= date('H:i:s', strtotime($e['recorded_at'])) ?>: <?= $e['is_focused']?'مركّز':'غير مركّز' ?>"></div>
      <?php endforeach; ?>
      <?php if (empty($events)): ?>
      <div style="color:var(--muted);font-size:.84rem">لا توجد بيانات كافية</div>
      <?php endif; ?>
    </div>
    <div class="tl-legend">
      <span>🟢 مركّز</span><span>🔴 غير مركّز</span><span>🟡 لا وجه</span>
    </div>
  </div>

  <div class="card">
    <h3>💡 نصائح لتحسين تركيزك</h3>
    <div class="advice-list">
      <?php
        $advices = [];
        if ($fp < 60) $advices[] = ['📵','أبعد التليفون عنك وقت المحاضرة'];
        if ($session['no_face_frames'] > $total * 0.2) $advices[] = ['💡','تأكد من الإضاءة الكويسة وابقى أمام الكاميرا'];
        if ($session['distracted_frames'] > $session['focused_frames']) $advices[] = ['🎧','جرّب سماعات العزل الصوتي للتركيز أكثر'];
        $advices[] = ['😴','النوم الكافي يحسّن التركيز بشكل ملحوظ'];
        $advices[] = ['🕐','خذ استراحة قصيرة كل ساعة لتجديد الطاقة'];
        foreach (array_slice($advices,0,4) as [$icon,$text]):
      ?>
      <div class="advice-item"><span class="advice-icon"><?= $icon ?></span><span><?= $text ?></span></div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<?php endif; ?>
</body>
</html>