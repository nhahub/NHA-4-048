<?php
require_once __DIR__ . '/../includes/config.php';
requireRole('teacher');
$user = getCurrentUser();
$db = getDB();

$lectureId = intval($_GET['id'] ?? 0);
$lecture = $db->prepare("SELECT * FROM lectures WHERE id = ? AND teacher_id = ?");
$lecture->execute([$lectureId, $user['id']]);
$lecture = $lecture->fetch();

if (!$lecture) {
    header('Location: dashboard.php');
    exit;
}

// Get enrolled students with their latest session
$students = $db->prepare("
    SELECT u.id, u.full_name, u.username,
           ms.id as session_id, ms.focus_percentage,
           ms.focused_frames, ms.total_frames, ms.final_score,
           (SELECT COUNT(*) FROM gaze_events ge 
            WHERE ge.session_id = ms.id AND ge.is_focused = 0 
            AND ge.recorded_at > DATE_SUB(NOW(), INTERVAL 1 MINUTE)) as recent_distractions
    FROM lecture_students ls
    JOIN users u ON ls.student_id = u.id
    LEFT JOIN monitoring_sessions ms ON ms.lecture_id = ? AND ms.student_id = u.id
    WHERE ls.lecture_id = ?
    ORDER BY ms.focus_percentage DESC
");
$students->execute([$lectureId, $lectureId]);
$students = $students->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>مراقبة مباشرة — <?= htmlspecialchars($lecture['title']) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #0a0e1a; --card: #111827; --border: #1f2937;
    --accent: #6366f1; --text: #f9fafb; --muted: #9ca3af;
    --success: #10b981; --warning: #f59e0b; --danger: #ef4444;
  }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Cairo', sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; }
  .top-bar {
    background: var(--card); border-bottom: 1px solid var(--border);
    padding: .9rem 2rem; display: flex; align-items: center; justify-content: space-between;
    position: sticky; top: 0; z-index: 50;
  }
  .top-bar-left { display: flex; align-items: center; gap: 1rem; }
  .back-btn { background: rgba(255,255,255,.07); border: 1px solid var(--border); color: var(--text); padding: .4rem .8rem; border-radius: 8px; text-decoration: none; font-size: .82rem; }
  .lecture-title { font-weight: 700; font-size: 1.05rem; }
  .live-badge { display: flex; align-items: center; gap: .4rem; background: rgba(239,68,68,.15); color: #fca5a5; padding: .35rem .8rem; border-radius: 20px; font-size: .8rem; font-weight: 600; }
  .live-dot { width: 8px; height: 8px; background: var(--danger); border-radius: 50%; animation: pulse 1.5s infinite; }
  @keyframes pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.6;transform:scale(1.3)} }
  .top-right { display: flex; align-items: center; gap: 1rem; }
  .stat-pill { background: rgba(255,255,255,.05); border: 1px solid var(--border); border-radius: 20px; padding: .35rem 1rem; font-size: .82rem; }
  .stat-pill span { color: var(--muted); }
  .main { padding: 1.5rem 2rem; }
  .overview-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; margin-bottom: 1.5rem; }
  .ov-card { background: var(--card); border: 1px solid var(--border); border-radius: 14px; padding: 1.2rem; text-align: center; }
  .ov-value { font-size: 2rem; font-weight: 900; }
  .ov-label { font-size: .78rem; color: var(--muted); margin-top: .2rem; }
  .students-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1rem; }
  .student-card {
    background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 1.3rem;
    transition: border-color .3s, box-shadow .3s;
  }
  .student-card.distracted { border-color: rgba(239,68,68,.5); box-shadow: 0 0 20px rgba(239,68,68,.15); }
  .student-card.focused { border-color: rgba(16,185,129,.3); }
  .student-header { display: flex; align-items: center; gap: .8rem; margin-bottom: 1rem; }
  .student-avatar {
    width: 42px; height: 42px; border-radius: 50%;
    background: linear-gradient(135deg, var(--accent), #8b5cf6);
    display: flex; align-items: center; justify-content: center; font-weight: 700; flex-shrink: 0;
  }
  .student-name { font-weight: 700; font-size: .92rem; }
  .student-status { font-size: .75rem; color: var(--muted); }
  .gaze-indicator {
    display: inline-flex; align-items: center; gap: .4rem;
    padding: .25rem .7rem; border-radius: 20px; font-size: .75rem; font-weight: 700; margin-bottom: 1rem;
  }
  .gaze-focused { background: rgba(16,185,129,.15); color: #6ee7b7; }
  .gaze-distracted { background: rgba(239,68,68,.15); color: #fca5a5; }
  .gaze-inactive { background: rgba(107,114,128,.15); color: var(--muted); }
  .focus-track { margin-bottom: .7rem; }
  .focus-track-header { display: flex; justify-content: space-between; font-size: .78rem; color: var(--muted); margin-bottom: .4rem; }
  .progress-bar { height: 8px; background: rgba(255,255,255,.08); border-radius: 4px; overflow: hidden; }
  .progress-fill { height: 100%; border-radius: 4px; transition: width 1s; }
  .mini-stats { display: grid; grid-template-columns: repeat(3,1fr); gap: .5rem; }
  .mini-stat { background: rgba(255,255,255,.04); border-radius: 8px; padding: .5rem; text-align: center; }
  .mini-stat-val { font-size: .95rem; font-weight: 700; }
  .mini-stat-lbl { font-size: .68rem; color: var(--muted); }
  .section-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; }
  .section-title { font-size: 1.05rem; font-weight: 700; }
  .access-code-box {
    background: rgba(99,102,241,.1); border: 1px dashed rgba(99,102,241,.4);
    border-radius: 12px; padding: .7rem 1.2rem; display: flex; align-items: center; gap: .8rem;
  }
  .access-code-label { font-size: .78rem; color: var(--muted); }
  .access-code-value { font-size: 1.4rem; font-weight: 900; letter-spacing: .1em; color: #a5b4fc; }
  .alert-list { display: flex; flex-direction: column; gap: .6rem; }
  .alert-item { background: rgba(239,68,68,.08); border: 1px solid rgba(239,68,68,.2); border-radius: 10px; padding: .7rem 1rem; display: flex; align-items: center; gap: .7rem; font-size: .82rem; }
  .alert-time { color: var(--muted); font-size: .75rem; margin-right: auto; }
  .refresh-note { font-size: .75rem; color: var(--muted); display: flex; align-items: center; gap: .4rem; }
</style>
</head>
<body>
<!-- Top Bar -->
<div class="top-bar">
  <div class="top-bar-left">
    <a href="dashboard.php" class="back-btn">← لوحة التحكم</a>
    <div>
      <div class="lecture-title"><?= htmlspecialchars($lecture['title']) ?></div>
    </div>
  </div>
  <div class="live-badge"><div class="live-dot"></div> مراقبة مباشرة</div>
  <div class="top-right">
    <div class="access-code-box">
      <span class="access-code-label">كود الانضمام</span>
      <span class="access-code-value"><?= $lecture['access_code'] ?></span>
    </div>
    <div class="refresh-note" id="refreshTimer">🔄 يتحدث تلقائياً كل 5 ثواني</div>
  </div>
</div>

<div class="main">
  <!-- Overview -->
  <div class="overview-grid" id="overviewGrid">
    <div class="ov-card">
      <div class="ov-value" id="ovTotal"><?= count($students) ?></div>
      <div class="ov-label">إجمالي الطلاب</div>
    </div>
    <div class="ov-card">
      <div class="ov-value" id="ovFocused" style="color:var(--success)">—</div>
      <div class="ov-label">مركّزون الآن</div>
    </div>
    <div class="ov-card">
      <div class="ov-value" id="ovDistracted" style="color:var(--danger)">—</div>
      <div class="ov-label">غير مركّزين</div>
    </div>
    <div class="ov-card">
      <div class="ov-value" id="ovAvgFocus" style="color:var(--warning)">—</div>
      <div class="ov-label">متوسط التركيز</div>
    </div>
  </div>

  <!-- Alerts -->
  <div id="alertsSection" style="margin-bottom:1.5rem;display:none">
    <div class="section-header">
      <div class="section-title">🚨 تنبيهات التشتيت</div>
    </div>
    <div class="alert-list" id="alertsList"></div>
  </div>

  <!-- Students Grid -->
  <div class="section-header">
    <div class="section-title">👨‍🎓 حالة الطلاب</div>
  </div>
  <div class="students-grid" id="studentsGrid">
    <?php foreach ($students as $s): ?>
    <div class="student-card" id="student-card-<?= $s['id'] ?>">
      <div class="student-header">
        <div class="student-avatar"><?= mb_substr($s['full_name'], 0, 1) ?></div>
        <div>
          <div class="student-name"><?= htmlspecialchars($s['full_name']) ?></div>
          <div class="student-status">@<?= $s['username'] ?></div>
        </div>
      </div>
      <div class="gaze-indicator gaze-inactive" id="gaze-<?= $s['id'] ?>">⚪ في انتظار البيانات</div>
      <div class="focus-track">
        <div class="focus-track-header">
          <span>نسبة التركيز</span>
          <span id="fp-text-<?= $s['id'] ?>"><?= round($s['focus_percentage'] ?? 0, 1) ?>%</span>
        </div>
        <div class="progress-bar">
          <div class="progress-fill" id="fp-bar-<?= $s['id'] ?>"
               style="width:<?= $s['focus_percentage'] ?? 0 ?>%;background:<?php
               $fp = $s['focus_percentage'] ?? 0;
               echo $fp >= 70 ? 'var(--success)' : ($fp >= 40 ? 'var(--warning)' : 'var(--danger)');
               ?>"></div>
        </div>
      </div>
      <div class="mini-stats">
        <div class="mini-stat">
          <div class="mini-stat-val" id="frames-focused-<?= $s['id'] ?>"><?= $s['focused_frames'] ?? 0 ?></div>
          <div class="mini-stat-lbl">مركّز</div>
        </div>
        <div class="mini-stat">
          <div class="mini-stat-val" id="frames-total-<?= $s['id'] ?>"><?= $s['total_frames'] ?? 0 ?></div>
          <div class="mini-stat-lbl">إجمالي</div>
        </div>
        <div class="mini-stat">
          <div class="mini-stat-val" id="distractions-<?= $s['id'] ?>"><?= $s['recent_distractions'] ?? 0 ?></div>
          <div class="mini-stat-lbl">تشتيت/دقيقة</div>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if (empty($students)): ?>
    <div style="grid-column:1/-1;text-align:center;padding:4rem;color:var(--muted)">
      <div style="font-size:3rem;margin-bottom:1rem">👥</div>
      <div>لا يوجد طلاب منضمون بعد. شارك الكود: <strong style="color:#a5b4fc"><?= $lecture['access_code'] ?></strong></div>
    </div>
    <?php endif; ?>
  </div>
</div>

<script>
const LECTURE_ID = <?= $lectureId ?>;
let alerts = [];

async function fetchLiveData() {
  try {
    const res = await fetch(`../api/live_data.php?lecture_id=${LECTURE_ID}`);
    const data = await res.json();
    if (!data.students) return;

    let focused = 0, distracted = 0, totalFp = 0, count = 0;

    data.students.forEach(s => {
      const card = document.getElementById(`student-card-${s.id}`);
      const gazeEl = document.getElementById(`gaze-${s.id}`);
      const fpBar = document.getElementById(`fp-bar-${s.id}`);
      const fpText = document.getElementById(`fp-text-${s.id}`);
      const framesFocused = document.getElementById(`frames-focused-${s.id}`);
      const framesTotal = document.getElementById(`frames-total-${s.id}`);
      const distractionsEl = document.getElementById(`distractions-${s.id}`);

      if (!card) return;

      // Update stats
      const fp = parseFloat(s.focus_percentage || 0);
      const color = fp >= 70 ? 'var(--success)' : fp >= 40 ? 'var(--warning)' : 'var(--danger)';

      if (fpBar) { fpBar.style.width = fp + '%'; fpBar.style.background = color; }
      if (fpText) fpText.textContent = fp.toFixed(1) + '%';
      if (framesFocused) framesFocused.textContent = s.focused_frames || 0;
      if (framesTotal) framesTotal.textContent = s.total_frames || 0;
      if (distractionsEl) distractionsEl.textContent = s.recent_distractions || 0;

      // Gaze status
      if (s.is_currently_focused === true) {
        gazeEl.className = 'gaze-indicator gaze-focused';
        gazeEl.textContent = '🟢 مركّز';
        card.classList.remove('distracted');
        card.classList.add('focused');
        focused++;
      } else if (s.is_currently_focused === false) {
        gazeEl.className = 'gaze-indicator gaze-distracted';
        gazeEl.textContent = '🔴 غير مركّز';
        card.classList.add('distracted');
        card.classList.remove('focused');
        distracted++;
        // Add alert if new distraction
        if (s.recent_distractions > 3) {
          addAlert(s.full_name, fp);
        }
      } else {
        gazeEl.className = 'gaze-indicator gaze-inactive';
        gazeEl.textContent = '⚪ غير متصل';
        card.classList.remove('distracted','focused');
      }

      totalFp += fp; count++;
    });

    // Update overview
    document.getElementById('ovFocused').textContent = focused;
    document.getElementById('ovDistracted').textContent = distracted;
    document.getElementById('ovAvgFocus').textContent = count > 0 ? (totalFp/count).toFixed(1) + '%' : '—';
  } catch (e) {
    console.log('Live data error:', e);
  }
}

function addAlert(name, fp) {
  const key = name + '_' + Math.floor(Date.now() / 30000);
  if (alerts.includes(key)) return;
  alerts.push(key);
  if (alerts.length > 20) alerts.shift();
  
  const section = document.getElementById('alertsSection');
  const list = document.getElementById('alertsList');
  section.style.display = 'block';
  
  const now = new Date().toLocaleTimeString('ar-EG');
  const item = document.createElement('div');
  item.className = 'alert-item';
  item.innerHTML = `⚠️ <strong>${name}</strong> غير مركّز — نسبة التركيز: ${fp.toFixed(0)}% <span class="alert-time">${now}</span>`;
  list.insertBefore(item, list.firstChild);
  if (list.children.length > 5) list.removeChild(list.lastChild);
}

// Poll every 5 seconds
fetchLiveData();
setInterval(fetchLiveData, 5000);

// Countdown timer
let countdown = 5;
setInterval(() => {
  countdown--;
  if (countdown <= 0) countdown = 5;
  document.getElementById('refreshTimer').textContent = `🔄 تحديث خلال ${countdown} ثانية`;
}, 1000);
</script>
</body>
</html>