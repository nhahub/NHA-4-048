"""
calibrate.py — شغّل الكاميرا وشوف قيم yaw/pitch الفعلية
استخدم: python calibrate.py

الهدف: تعرف القيم الصح لـ YAW_THRESHOLD و PITCH_THRESHOLD
"""

import cv2
import math
import numpy as np

face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

MODEL_POINTS = np.array([
    (0.0,    0.0,    0.0),
    (0.0,  -63.6,  -12.5),
    (-43.3,  32.7,  -26.0),
    ( 43.3,  32.7,  -26.0),
    (-28.9, -28.9,  -24.1),
    ( 28.9, -28.9,  -24.1),
], dtype=np.float64)


def get_pose(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    h, w = frame.shape[:2]
    faces = face_cascade.detectMultiScale(gray, 1.1, 5, minSize=(80, 80))
    if len(faces) == 0:
        return None, None, None

    x, y, fw, fh = max(faces, key=lambda f: f[2] * f[3])
    image_points = np.array([
        [x + fw // 2,     y + fh // 2],
        [x + fw // 2,     y + fh],
        [x + fw // 4,     y + fh // 3],
        [x + 3 * fw // 4, y + fh // 3],
        [x + fw // 3,     y + 2 * fh // 3],
        [x + 2 * fw // 3, y + 2 * fh // 3],
    ], dtype=np.float64)

    focal = w
    cam = np.array([[focal, 0, w/2], [0, focal, h/2], [0, 0, 1]], dtype=np.float64)
    ok, rvec, _ = cv2.solvePnP(MODEL_POINTS, image_points, cam, np.zeros((4, 1)),
                                flags=cv2.SOLVEPNP_ITERATIVE)
    if not ok:
        return None, None, None

    R, _ = cv2.Rodrigues(rvec)
    sy = math.sqrt(R[0][0]**2 + R[1][0]**2)
    yaw   = math.degrees(math.atan2(-R[2][0], sy))
    pitch = math.degrees(math.atan2(R[2][1], R[2][2]) if sy > 1e-6
                         else math.atan2(-R[1][2], R[1][1]))
    if abs(pitch) > 90:
        pitch -= math.copysign(180, pitch)

    return round(yaw, 1), round(pitch, 1), (x, y, fw, fh)


def main():
    cap = cv2.VideoCapture(0)
    print("=" * 50)
    print("CALIBRATION MODE")
    print("ابص في الشاشة بشكل طبيعي — لاحظ قيم yaw/pitch")
    print("اضغط Q للخروج")
    print("=" * 50)

    # Thresholds للتجربة — عدّلهم هنا وشوف الفرق
    YAW_TH   = 20
    PITCH_TH = 15

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame = cv2.flip(frame, 1)  # mirror
        yaw, pitch, box = get_pose(frame)

        if box is not None:
            x, y, fw, fh = box
            focused = abs(yaw) <= YAW_TH and abs(pitch) <= PITCH_TH
            color = (0, 255, 0) if focused else (0, 0, 255)
            label = "FOCUSED" if focused else "NOT FOCUSED"

            cv2.rectangle(frame, (x, y), (x+fw, y+fh), color, 2)
            cv2.putText(frame, f"Yaw: {yaw:.1f}  (threshold: ±{YAW_TH})",
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
            cv2.putText(frame, f"Pitch: {pitch:.1f}  (threshold: ±{PITCH_TH})",
                        (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
            cv2.putText(frame, label,
                        (10, 100), cv2.FONT_HERSHEY_SIMPLEX, 1.2, color, 3)
            cv2.putText(frame, f"Edit YAW_TH/PITCH_TH in this script to tune",
                        (10, frame.shape[0] - 20),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)
        else:
            cv2.putText(frame, "NO FACE DETECTED",
                        (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 165, 255), 2)

        cv2.imshow("Calibration — Press Q to quit", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    print("\nالقيم الموصى بيها بعد الكاليبريشن:")
    print(f"  YAW_THRESHOLD   = {YAW_TH}")
    print(f"  PITCH_THRESHOLD = {PITCH_TH}")
    print("انقلهم لـ analyze_frame.php")


if __name__ == "__main__":
    main()
