import io
import os
import csv
import torch
import torch.nn as nn
import numpy as np

from PIL import Image
from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime

from torchvision import transforms
from torchvision.models import resnet50

# =========================
# CONFIG
# =========================

MODEL_PATH = os.environ.get(
    "MODEL_PATH",
    r"D:\gaze_resnet_v3_best.pth"
)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

LOG_PATH = "gaze_log.csv"

# =========================
# THRESHOLD
# مركزة:     pitch ≈ -0.22 أو أقل (diff كبير)
# مش مركزة: pitch ≈ -0.14 أو -0.15 (diff صغير)
# =========================
YAW_CENTER      = -0.01
PITCH_CENTER    = -0.14

YAW_MIN_DIFF   = 0.04
PITCH_MIN_DIFF = 0.04

print(f"DEVICE: {DEVICE}")

# =========================
# FASTAPI
# =========================

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =========================
# MODEL
# =========================

class GazeResNet(nn.Module):
    def __init__(self):
        super().__init__()

        backbone = resnet50(weights=None)

        self.features = nn.Sequential(
            *list(backbone.children())[:-2]
        )

        self.pool = nn.AdaptiveAvgPool2d((1, 1))

        self.fc = nn.Sequential(
            nn.Flatten(),
            nn.Linear(2048, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(512, 2)
        )

    def forward(self, x):
        x = self.features(x)
        x = self.pool(x)
        x = self.fc(x)
        return x


model = GazeResNet().to(DEVICE)

checkpoint = torch.load(MODEL_PATH, map_location=DEVICE)

if isinstance(checkpoint, dict):
    state_dict = checkpoint.get("model_state", checkpoint.get("state_dict", checkpoint))
else:
    state_dict = checkpoint

new_state_dict = {}
for k, v in state_dict.items():
    if k.startswith("module."):
        k = k[7:]
    new_state_dict[k] = v

try:
    model.load_state_dict(new_state_dict, strict=True)
    print("MODEL LOADED (strict=True)")
except Exception as e:
    print("STRICT LOAD FAILED")
    print(e)
    model.load_state_dict(new_state_dict, strict=False)
    print("MODEL LOADED (strict=False)")

model.eval()

# =========================
# IMAGE TRANSFORM
# =========================

transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
])

# =========================
# ROUTES
# =========================

@app.get("/")
async def root():
    return {"message": "Gaze API Running"}

@app.get("/health")
async def health():
    return {"status": "ok", "device": str(DEVICE)}

@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    try:
        contents = await file.read()
        image = Image.open(io.BytesIO(contents)).convert("RGB")
        tensor = transform(image)
        tensor = tensor.unsqueeze(0).to(DEVICE)

        with torch.no_grad():
            output = model(tensor)
            yaw   = float(output[0][0].item())
            pitch = float(output[0][1].item())

        # LOG
        with open(LOG_PATH, "a", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                round(yaw, 4),
                round(pitch, 4)
            ])

        # =========================
        # التركيز — الموديل معكوس
        # مركزة = pitch بعيد عن الـ center (diff كبير)
        # مش مركزة = pitch قريب من الـ center (diff صغير)
        # =========================
        pitch_diff = abs(pitch - PITCH_CENTER)
        yaw_diff   = abs(yaw   - YAW_CENTER)

        focused = (pitch_diff >= PITCH_MIN_DIFF)

        confidence = round(min(100, (pitch_diff / 0.12) * 100), 1)

        print("\n====================")
        print(f"YAW        = {round(yaw, 4)}  (diff={round(yaw_diff,4)})")
        print(f"PITCH      = {round(pitch, 4)}  (diff={round(pitch_diff,4)})")
        print(f"FOCUSED    = {focused}")
        print(f"CONFIDENCE = {confidence}")
        print("====================\n")

        return {
            "face_detected": True,
            "yaw":        yaw,
            "pitch":      pitch,
            "focused":    focused,
            "confidence": confidence,
            "label":      "focused" if focused else "not_focused"
        }

    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()
        return {
            "face_detected": False,
            "focused":       False,
            "error":         str(e)
        }

print("\nSERVER READY — http://127.0.0.1:8000")