from flask import Flask, request, jsonify
from flask_cors import CORS

import cv2
import numpy as np
import math
from PIL import Image
import base64
import io
import time
import os
import torch
import torch.nn as nn
from torchvision.models import resnet50
from torchvision import transforms
from collections import OrderedDict

app = Flask(__name__)
CORS(app)

# =========================
# CONFIG
# =========================

MODEL_PATH            = r"D:\gaze_resnet_v3_best.pth"
YAW_THRESHOLD         = 25
PITCH_THRESHOLD       = 20
DISTRACTION_DELAY_SEC = 5

# =========================
# DEVICE
# =========================

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"[INFO] Device: {DEVICE}")

# =========================
# MODEL
# =========================

class GazeResNet(nn.Module):
    def __init__(self):
        super().__init__()
        backbone = resnet50(weights=None)
        self.features = nn.Sequential(*list(backbone.children())[:-2])
        self.pool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Sequential(
            nn.Flatten(),
            nn.Linear(2048, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(512, 2)
        )

    def forward(self, x):
        x = self.features(x)
        x = self.pool(x)
        return self.fc(x)

# =========================
# LOAD MODEL
# =========================

def load_model():
    if not os.path.exists(MODEL_PATH):
        print(f"[WARN] Model not found — geometry-only mode")
        return None

    m = GazeResNet().to(DEVICE)
    checkpoint = torch.load(MODEL_PATH, map_location=DEVICE)

    if isinstance(checkpoint, dict):
        print("Checkpoint keys:", list(checkpoint.keys()))
        if "model_state" in checkpoint:
            state_dict = checkpoint["model_state"]
        elif "state_dict" in checkpoint:
            state_dict = checkpoint["state_dict"]
        else:
            state_dict = checkpoint
    else:
        state_dict = checkpoint

    new_state_dict = OrderedDict()
    for k, v in state_dict.items():
        name = k[7:] if k.startswith("module.") else k
        new_state_dict[name] = v

    try:
        m.load_state_dict(new_state_dict, strict=True)
        print("[INFO] Model loaded (strict=True)")
    except Exception as e:
        print(f"[WARN] strict=True failed: {e}")
        missing, unexpected = m.load_state_dict(new_state_dict, strict=False)
        print("MISSING:", missing)
        print("UNEXPECTED:", unexpected)
        print("[INFO] Model loaded (strict=False)")

    m.eval()
    return m

try:
    model = load_model()
    MODEL_LOADED = model is not None
except Exception as e:
    print(f"[ERROR] {e}")
    MODEL_LOADED = False
    model = None

# =========================
# TRANSFORM
# =========================

INFER_TRANSFORM = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
])

# =========================
# FACE DETECTOR — OpenCV بدل MediaPipe
# =========================

face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
)

# =========================
# FACE MODEL POINTS
# =========================

model_points = np.array([
    (0.0,    0.0,    0.0),
    (0.0,   -63.6, -12.5),
    (-43.3,  32.7, -26.0),
    (43.3,   32.7, -26.0),
    (-28.9, -28.9, -24.1),
    (28.9,  -28.9, -24.1)
], dtype=np.float64)

# =========================
# HEAD POSE — solvePnP بدون MediaPipe
# =========================

def get_head_pose(frame_rgb):
    gray = cv2.cvtColor(frame_rgb, cv2.COLOR_RGB2GRAY)
    h, w = frame_rgb.shape[:2]

    faces = face_cascade.detectMultiScale(
        gray, scaleFactor=1.1, minNeighbors=5, minSize=(80, 80)
    )

    if len(faces) == 0:
        return None, None, None, False

    x, y, fw, fh = max(faces, key=lambda f: f[2] * f[3])

    # نقاط تقريبية من bounding box
    image_points = np.array([
        [x + fw // 2,     y + fh // 2],   # أنف
        [x + fw // 2,     y + fh],         # ذقن
        [x + fw // 4,     y + fh // 3],    # عين يسرى
        [x + 3*fw // 4,   y + fh // 3],    # عين يمنى
        [x + fw // 3,     y + 2*fh // 3],  # فم يسار
        [x + 2*fw // 3,   y + 2*fh // 3],  # فم يمين
    ], dtype=np.float64)

    focal      = w
    cam_matrix = np.array([
        [focal, 0,     w / 2],
        [0,     focal, h / 2],
        [0,     0,     1    ]
    ], dtype=np.float64)
    dist = np.zeros((4, 1))

    ok, rvec, tvec = cv2.solvePnP(
        model_points, image_points, cam_matrix, dist,
        flags=cv2.SOLVEPNP_ITERATIVE
    )

    if not ok:
        return None, None, None, True

    R, _ = cv2.Rodrigues(rvec)

    # Euler angles مصححة
    sy       = math.sqrt(R[0][0]**2 + R[1][0]**2)
    singular = sy < 1e-6

    if not singular:
        pitch_rad = math.atan2( R[2][1], R[2][2])
        yaw_rad   = math.atan2(-R[2][0], sy)
    else:
        pitch_rad = math.atan2(-R[1][2], R[1][1])
        yaw_rad   = math.atan2(-R[2][0], sy)

    yaw   = math.degrees(yaw_rad)
    pitch = math.degrees(pitch_rad)

    if abs(pitch) > 90:
        pitch = pitch - math.copysign(180, pitch)

    return round(yaw, 1), round(pitch, 1), (x, y, fw, fh), True

# =========================
# GRACE PERIOD TRACKER
# =========================

gaze_tracker = {}

def check_focus_with_duration(raw_focused, student_id):
    now = time.time()
    if student_id not in gaze_tracker:
        gaze_tracker[student_id] = {"away_since": None}
    tracker = gaze_tracker[student_id]

    if raw_focused:
        tracker["away_since"] = None
        return True

    if tracker["away_since"] is None:
        tracker["away_since"] = now
        return True

    return (now - tracker["away_since"]) < DISTRACTION_DELAY_SEC

# =========================
# IMAGE DECODER
# =========================

def decode_base64_image(b64):
    if "," in b64:
        b64 = b64.split(",")[1]
    return Image.open(io.BytesIO(base64.b64decode(b64))).convert("RGB")

# =========================
# PREDICT
# =========================

def predict_gaze(pil_image, student_id="default"):

    frame = np.array(pil_image)

    yaw, pitch, face_box, face_detected = get_head_pose(frame)

    if not face_detected or yaw is None:
        focused      = check_focus_with_duration(False, student_id)
        away_since   = gaze_tracker.get(student_id, {}).get("away_since")
        seconds_away = round(time.time() - away_since, 1) if away_since else 0
        return {
            "focused":       focused,
            "label":         "no_face",
            "yaw":           0.0,
            "pitch":         0.0,
            "confidence":    0,
            "face_detected": False,
            "looking_away":  not focused,
            "seconds_away":  seconds_away,
            "probabilities": {"focused": 0, "not_focused": 100}
        }

    # --- Model inference على وجه المقطوع ---
    if MODEL_LOADED and model is not None and face_box is not None:
        try:
            x, y, fw, fh = face_box
            face_crop = pil_image.crop((x, y, x + fw, y + fh))
            tensor    = INFER_TRANSFORM(face_crop).unsqueeze(0).to(DEVICE)
            with torch.no_grad():
                out = model(tensor)[0].cpu().numpy()
            # الموديل بيطلع yaw, pitch
            model_yaw   = round(float(out[0]), 1)
            model_pitch = round(float(out[1]), 1)
            # متوسط بين الموديل والـ geometry
            yaw   = round((yaw   + model_yaw)   / 2, 1)
            pitch = round((pitch + model_pitch) / 2, 1)
            print(f"[MODEL] model_yaw={model_yaw}° model_pitch={model_pitch}°")
        except Exception as e:
            print(f"[WARN] Model inference failed: {e}")

    # --- Focus decision ---
    raw_focused = (abs(yaw) <= YAW_THRESHOLD and abs(pitch) <= PITCH_THRESHOLD)
    focused     = check_focus_with_duration(raw_focused, student_id)

    away_since   = gaze_tracker.get(student_id, {}).get("away_since")
    seconds_away = round(time.time() - away_since, 1) if away_since else 0

    yaw_score   = max(0.0, 1 - abs(yaw)   / YAW_THRESHOLD)
    pitch_score = max(0.0, 1 - abs(pitch) / PITCH_THRESHOLD)
    confidence  = round((yaw_score + pitch_score) / 2 * 100, 1)
    label       = "focused" if raw_focused else "not_focused"

    print(f"[GAZE] yaw={yaw}° pitch={pitch}° → {label} | conf={confidence}% | away={seconds_away}s")

    return {
        "focused":       focused,
        "label":         label,
        "yaw":           yaw,
        "pitch":         pitch,
        "confidence":    confidence,
        "face_detected": True,
        "looking_away":  not focused,
        "seconds_away":  seconds_away,
        "probabilities": {
            "focused":     confidence,
            "not_focused": round(100 - confidence, 1)
        }
    }

# =========================
# ROUTES
# =========================

@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status":                "ok",
        "model_loaded":          MODEL_LOADED,
        "device":                str(DEVICE),
        "method":                "OpenCV Haar + GazeResNet50 + solvePnP",
        "yaw_threshold_deg":     YAW_THRESHOLD,
        "pitch_threshold_deg":   PITCH_THRESHOLD,
        "distraction_delay_sec": DISTRACTION_DELAY_SEC
    })

@app.route("/analyze", methods=["POST"])
def analyze():
    try:
        data = request.get_json()
        if not data or "image" not in data:
            return jsonify({"error": "No image provided"}), 400

        student_id = str(data.get("student_id", "default"))
        image      = decode_base64_image(data["image"])
        result     = predict_gaze(image, student_id)
        result["timestamp"] = time.time()
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# =========================
# MAIN
# =========================

if __name__ == "__main__":
    print("[INFO] Starting GazeTrack API...")
    print(f"[INFO] Model path: {MODEL_PATH}")
    print(f"[INFO] Thresholds: yaw=±{YAW_THRESHOLD}° | pitch=±{PITCH_THRESHOLD}°")
    print(f"[INFO] Distraction delay: {DISTRACTION_DELAY_SEC}s")
    app.run(host="0.0.0.0", port=5000, debug=False)