<?php
// join_lecture.php
require_once __DIR__ . '/../includes/config.php';
requireRole('student');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../student/dashboard.php'); exit;
}

$code = strtoupper(trim($_POST['access_code'] ?? ''));
if (!$code) {
    header('Location: ../student/dashboard.php?error=no_code'); exit;
}

$db = getDB();
$lecture = $db->prepare("SELECT * FROM lectures WHERE access_code = ? AND status != 'ended'");
$lecture->execute([$code]);
$lecture = $lecture->fetch();

if (!$lecture) {
    header('Location: ../student/dashboard.php?error=invalid_code'); exit;
}

// Check if already enrolled
$existing = $db->prepare("SELECT id FROM lecture_students WHERE lecture_id = ? AND student_id = ?");
$existing->execute([$lecture['id'], $_SESSION['user_id']]);
if ($existing->fetch()) {
    header('Location: ../student/dashboard.php?info=already_enrolled'); exit;
}

$db->prepare("INSERT INTO lecture_students (lecture_id, student_id) VALUES (?,?)")
   ->execute([$lecture['id'], $_SESSION['user_id']]);

header('Location: ../student/dashboard.php?success=joined');