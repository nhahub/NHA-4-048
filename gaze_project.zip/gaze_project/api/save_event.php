<?php
require_once __DIR__ . '/../includes/config.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isLoggedIn()) {
    echo json_encode(['error' => 'Unauthorized']); exit;
}

$data = json_decode(file_get_contents('php://input'), true);
if (!$data) { echo json_encode(['error' => 'No data']); exit; }

$db = getDB();

// Insert gaze event
$stmt = $db->prepare("
    INSERT INTO gaze_events (session_id, student_id, lecture_id, is_focused, confidence, label, face_detected)
    VALUES (?, ?, ?, ?, ?, ?, ?)
");
$stmt->execute([
    $data['session_id'],
    $data['student_id'],
    $data['lecture_id'],
    $data['is_focused'] ? 1 : 0,
    floatval($data['confidence'] ?? 0),
    $data['label'] ?? '',
    $data['face_detected'] ? 1 : 0
]);

// Update session stats
if (isset($data['stats'])) {
    $s = $data['stats'];
    $total = intval($s['total'] ?? 0);
    $focused = intval($s['focused'] ?? 0);
    $fp = $total > 0 ? round($focused / $total * 100, 2) : 0;
    $score = calculateScore($fp);

    $db->prepare("
        UPDATE monitoring_sessions
        SET total_frames = ?, focused_frames = ?, distracted_frames = ?,
            no_face_frames = ?, focus_percentage = ?, final_score = ?
        WHERE id = ?
    ")->execute([
        $total,
        $focused,
        intval($s['distracted'] ?? 0),
        intval($s['noFace'] ?? 0),
        $fp,
        $score,
        $data['session_id']
    ]);
}

echo json_encode(['ok' => true]);