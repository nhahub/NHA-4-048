<?php

require_once __DIR__ . '/../includes/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['image'])) {
    echo json_encode(['error' => 'No image']);
    exit;
}

$imageData = $data['image'];

if (strpos($imageData, ',') !== false) {
    $imageData = explode(',', $imageData)[1];
}

$imageBinary = base64_decode($imageData);

if (!$imageBinary || strlen($imageBinary) < 100) {
    echo json_encode(['error' => 'Invalid image data']);
    exit;
}

// Save to temp file (safe for binary data)
$tmpFile = tempnam(sys_get_temp_dir(), 'frame_') . '.jpg';
file_put_contents($tmpFile, $imageBinary);

$ch = curl_init('http://127.0.0.1:8000/predict');

curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_TIMEOUT        => 10,
    CURLOPT_CONNECTTIMEOUT => 5,
    CURLOPT_POSTFIELDS     => [
        'file' => new CURLFile($tmpFile, 'image/jpeg', 'frame.jpg')
    ]
]);

$response = curl_exec($ch);
$curlError = curl_errno($ch) ? curl_error($ch) : null;
curl_close($ch);
unlink($tmpFile);

if ($curlError) {
    echo json_encode(['error' => $curlError]);
    exit;
}

$result = json_decode($response, true);

if (!$result) {
    echo json_encode(['error' => 'Invalid response from model server']);
    exit;
}

echo json_encode($result);
exit;