<?php
require_once __DIR__ . '/../includes/config.php';
header('Content-Type: application/json');

if (!isLoggedIn() || !in_array($_SESSION['role'], ['teacher', 'admin'])) {
    echo json_encode(['error' => 'Unauthorized']); exit;
}

$lectureId = intval($_GET['lecture_id'] ?? 0);
$db = getDB();

$students = $db->prepare("
    SELECT u.id, u.full_name, u.username,
           ms.focus_percentage, ms.focused_frames, ms.total_frames, ms.final_score,
           (SELECT ge.is_focused FROM gaze_events ge WHERE ge.student_id = u.id AND ge.lecture_id = ?
            ORDER BY ge.recorded_at DESC LIMIT 1) as current_focused,
           (SELECT COUNT(*) FROM gaze_events ge
            WHERE ge.student_id = u.id AND ge.lecture_id = ? AND ge.is_focused = 0
            AND ge.recorded_at > DATE_SUB(NOW(), INTERVAL 1 MINUTE)) as recent_distractions
    FROM lecture_students ls
    JOIN users u ON ls.student_id = u.id
    LEFT JOIN monitoring_sessions ms ON ms.lecture_id = ? AND ms.student_id = u.id
    WHERE ls.lecture_id = ?
");
$students->execute([$lectureId, $lectureId, $lectureId, $lectureId]);
$rows = $students->fetchAll();

$result = array_map(function($s) {
    return [
        'id' => $s['id'],
        'full_name' => $s['full_name'],
        'username' => $s['username'],
        'focus_percentage' => round($s['focus_percentage'] ?? 0, 1),
        'focused_frames' => $s['focused_frames'] ?? 0,
        'total_frames' => $s['total_frames'] ?? 0,
        'is_currently_focused' => $s['current_focused'] !== null ? (bool)$s['current_focused'] : null,
        'recent_distractions' => $s['recent_distractions'] ?? 0,
    ];
}, $rows);

echo json_encode(['students' => $result, 'timestamp' => time()]);