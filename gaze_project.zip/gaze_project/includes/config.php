<?php
// ─── Database Configuration ────────────────────────────────────────────────
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'gaze_monitor');

// ─── Python API URL — FastAPI على port 8000 ────────────────────────────────
define('PYTHON_API_URL', 'http://127.0.0.1:8000');

// ─── App Settings ─────────────────────────────────────────────────────────
define('APP_NAME', 'GazeTrack');
define('APP_URL', 'http://localhost/gaze_project');
define('SESSION_TIMEOUT', 3600);

// ─── Analysis Settings ────────────────────────────────────────────────────
define('CAPTURE_INTERVAL_MS', 3000);
define('DISTRACTION_THRESHOLD_SEC', 15);
define('LOW_FOCUS_THRESHOLD', 40);

// ─── PDO Connection ───────────────────────────────────────────────────────
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            die(json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}

// ─── Session Start ────────────────────────────────────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ─── Auth Helpers ─────────────────────────────────────────────────────────
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']) && isset($_SESSION['role']);
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: ' . APP_URL . '/login.php');
        exit;
    }
}

function requireRole(string $role): void {
    requireLogin();
    if ($_SESSION['role'] !== $role && $_SESSION['role'] !== 'admin') {
        header('Location: ' . APP_URL . '/unauthorized.php');
        exit;
    }
}

function getCurrentUser(): ?array {
    if (!isLoggedIn()) return null;
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch() ?: null;
}

// ─── API Helper (غير مستخدمة مع FastAPI لكن محتفظ بيها) ──────────────────
function callPythonAPI(string $endpoint, array $data = [], string $method = 'POST'): array {
    $url = PYTHON_API_URL . $endpoint;
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
    ]);
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    }
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($response === false || $httpCode !== 200) {
        return ['error' => 'Python API غير متاحة', 'http_code' => $httpCode];
    }
    return json_decode($response, true) ?? ['error' => 'Invalid JSON response'];
}

// ─── Score Helpers ─────────────────────────────────────────────────────────
function calculateScore(float $focusPercentage): string {
    if ($focusPercentage >= 80) return 'excellent';
    if ($focusPercentage >= 60) return 'good';
    if ($focusPercentage >= 40) return 'average';
    return 'poor';
}

function scoreLabel(string $score): string {
    return match($score) {
        'excellent' => 'ممتاز',
        'good'      => 'جيد',
        'average'   => 'مقبول',
        'poor'      => 'ضعيف',
        default     => 'غير محدد'
    };
}

function scoreColor(string $score): string {
    return match($score) {
        'excellent' => '#10b981',
        'good'      => '#3b82f6',
        'average'   => '#f59e0b',
        'poor'      => '#ef4444',
        default     => '#6b7280'
    };
}
?>