<?php
// start_lecture.php
require_once __DIR__ . '/../includes/config.php';
requireRole('teacher');
$id = intval($_GET['id'] ?? 0);
$db = getDB();
$db->prepare("UPDATE lectures SET status='active', started_at=NOW() WHERE id=? AND teacher_id=?")
   ->execute([$id, $_SESSION['user_id']]);
header("Location: lecture_live.php?id=$id");