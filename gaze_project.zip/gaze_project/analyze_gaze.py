import pandas as pd
import matplotlib.pyplot as plt
import os

LOG_PATH = "gaze_log.csv"

# =========================
# CHECK FILE EXISTS
# =========================

if not os.path.exists(LOG_PATH):
    print("❌ مفيش فايل gaze_log.csv لسه!")
    print("   شغّل server2.py الأول واستخدم الموقع شوية.")
    exit()

# =========================
# LOAD DATA
# =========================

df = pd.read_csv(LOG_PATH, names=["time", "yaw", "pitch"])

print(f"\n✅ عدد الـ frames المسجلة: {len(df)}\n")

# =========================
# STATISTICS
# =========================

print("=" * 40)
print("إحصائيات YAW و PITCH:")
print("=" * 40)
print(df[["yaw", "pitch"]].describe().round(2))

print("\n" + "=" * 40)
print("نسبة الـ frames جوه الثريشولد الحالي (22, 20):")
focused = df[(df["yaw"].abs() <= 22) & (df["pitch"].abs() <= 20)]
print(f"  مركز    : {len(focused)} frame  ({100*len(focused)/len(df):.1f}%)")
print(f"  مش مركز : {len(df)-len(focused)} frame  ({100*(len(df)-len(focused))/len(df):.1f}%)")
print("=" * 40)

# =========================
# SUGGESTED THRESHOLD
# =========================

yaw_95 = df["yaw"].abs().quantile(0.95)
pitch_95 = df["pitch"].abs().quantile(0.95)

print(f"\n💡 ثريشولد مقترح بناءً على بياناتك:")
print(f"   YAW   = {yaw_95:.1f}  (بدل 22)")
print(f"   PITCH = {pitch_95:.1f}  (بدل 20)")
print("\n   يعني غيّر في server2.py:")
print(f"   focused = (abs(yaw) <= {yaw_95:.0f} and abs(pitch) <= {pitch_95:.0f})")

# =========================
# PLOT
# =========================

fig, axes = plt.subplots(1, 2, figsize=(12, 5))
fig.suptitle("توزيع YAW و PITCH", fontsize=14)

axes[0].hist(df["yaw"], bins=50, color="steelblue", edgecolor="white")
axes[0].axvline(22, color="red", linestyle="--", label="threshold +22")
axes[0].axvline(-22, color="red", linestyle="--", label="threshold -22")
axes[0].set_title("YAW")
axes[0].set_xlabel("درجات")
axes[0].set_ylabel("عدد الـ frames")
axes[0].legend()

axes[1].hist(df["pitch"], bins=50, color="coral", edgecolor="white")
axes[1].axvline(20, color="red", linestyle="--", label="threshold +20")
axes[1].axvline(-20, color="red", linestyle="--", label="threshold -20")
axes[1].set_title("PITCH")
axes[1].set_xlabel("درجات")
axes[1].legend()

plt.tight_layout()
plt.savefig("gaze_analysis.png", dpi=150)
plt.show()

print("\n✅ الرسم اتحفظ في gaze_analysis.png")