<?php
require_once __DIR__ . '/../includes/config.php';
requireRole('student');
$user = getCurrentUser();
$db = getDB();

$lectureId = intval($_GET['lecture_id'] ?? 0);

// Verify student is enrolled
$lecture = $db->prepare("
    SELECT l.* FROM lectures l
    JOIN lecture_students ls ON l.id = ls.lecture_id
    WHERE l.id = ? AND ls.student_id = ? AND l.status = 'active'
");
$lecture->execute([$lectureId, $user['id']]);
$lecture = $lecture->fetch();

if (!$lecture) {
    header('Location: dashboard.php?error=not_enrolled');
    exit;
}

// Create or get monitoring session
$session = $db->prepare("SELECT * FROM monitoring_sessions WHERE lecture_id = ? AND student_id = ?");
$session->execute([$lectureId, $user['id']]);
$session = $session->fetch();

if (!$session) {
    $db->prepare("INSERT INTO monitoring_sessions (lecture_id, student_id) VALUES (?,?)")->execute([$lectureId, $user['id']]);
    $sessionId = $db->lastInsertId();
} else {
    $sessionId = $session['id'];
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>مراقبة التركيز — GazeTrack</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #0a0e1a; --card: #111827; --border: #1f2937;
    --accent: #6366f1; --text: #f9fafb; --muted: #9ca3af;
    --success: #10b981; --warning: #f59e0b; --danger: #ef4444;
  }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Cairo', sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; }
  .top-bar {
    background: var(--card); border-bottom: 1px solid var(--border);
    padding: .9rem 2rem; display: flex; align-items: center; justify-content: space-between;
  }
  .back-btn { background: rgba(255,255,255,.07); border: 1px solid var(--border); color: var(--text); padding: .4rem .8rem; border-radius: 8px; text-decoration: none; font-size: .82rem; }
  .lecture-title { font-weight: 700; }
  .layout { display: grid; grid-template-columns: 1fr 380px; gap: 1.5rem; padding: 1.5rem 2rem; max-width: 1400px; margin: 0 auto; }
  /* Camera Panel */
  .camera-panel { display: flex; flex-direction: column; gap: 1rem; }
  .camera-box {
    background: var(--card); border: 1px solid var(--border); border-radius: 20px;
    overflow: hidden; position: relative;
  }
  .camera-header { padding: 1rem 1.2rem; display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid var(--border); }
  .camera-header h3 { font-size: .95rem; font-weight: 700; }
  #cameraFeed {
    width: 100%; aspect-ratio: 4/3; object-fit: cover; display: block;
    transform: scaleX(-1); /* Mirror effect */
  }
  #cameraCanvas { display: none; }
  .camera-overlay {
    position: absolute; bottom: 0; left: 0; right: 0;
    background: linear-gradient(transparent, rgba(0,0,0,.8));
    padding: 1.5rem 1.2rem 1rem;
    display: flex; align-items: center; justify-content: space-between;
  }
  .gaze-status {
    display: flex; align-items: center; gap: .6rem;
    background: rgba(0,0,0,.6); backdrop-filter: blur(10px);
    border-radius: 30px; padding: .5rem 1.1rem;
    font-weight: 700; font-size: .9rem;
  }
  .gaze-dot { width: 10px; height: 10px; border-radius: 50%; }
  .gaze-dot.focused { background: var(--success); box-shadow: 0 0 10px var(--success); animation: glow 1.5s infinite; }
  .gaze-dot.distracted { background: var(--danger); box-shadow: 0 0 10px var(--danger); animation: glow 0.8s infinite; }
  .gaze-dot.idle { background: var(--muted); }
  @keyframes glow { 0%,100%{opacity:1} 50%{opacity:.4} }
  .confidence-pill { background: rgba(0,0,0,.6); backdrop-filter: blur(10px); border-radius: 20px; padding: .35rem .8rem; font-size: .78rem; }
  /* Stats Panel */
  .stats-panel { display: flex; flex-direction: column; gap: 1rem; }
  .stat-box { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 1.3rem; }
  .stat-box h4 { font-size: .85rem; color: var(--muted); margin-bottom: 1rem; font-weight: 600; }
  .big-number { font-size: 3rem; font-weight: 900; line-height: 1; }
  .big-label { font-size: .8rem; color: var(--muted); margin-top: .3rem; }
  /* Ring chart */
  .ring-wrap { display: flex; align-items: center; gap: 1.5rem; }
  .ring-svg { width: 90px; height: 90px; flex-shrink: 0; }
  .ring-stats { flex: 1; }
  .ring-stat { display: flex; justify-content: space-between; font-size: .82rem; padding: .3rem 0; border-bottom: 1px solid rgba(255,255,255,.05); }
  .ring-stat:last-child { border-bottom: none; }
  .ring-stat span { color: var(--muted); }
  /* Timeline */
  .timeline { display: flex; gap: 3px; flex-wrap: wrap; }
  .tl-block { width: 16px; height: 16px; border-radius: 3px; background: rgba(255,255,255,.08); transition: background .3s; }
  .tl-block.focused { background: var(--success); }
  .tl-block.distracted { background: var(--danger); }
  .tl-block.no-face { background: var(--warning); }
  /* Alert toast */
  .alert-toast {
    position: fixed; top: 1.5rem; left: 50%; transform: translateX(-50%) translateY(-120%);
    background: rgba(239,68,68,.95); color: white; border-radius: 14px;
    padding: .8rem 1.5rem; font-weight: 700; font-size: .9rem;
    display: flex; align-items: center; gap: .6rem; z-index: 1000;
    transition: transform .4s cubic-bezier(.34,1.56,.64,1);
    white-space: nowrap; box-shadow: 0 10px 30px rgba(0,0,0,.4);
  }
  .alert-toast.show { transform: translateX(-50%) translateY(0); }
  /* Camera permission request */
  .camera-placeholder {
    width: 100%; aspect-ratio: 4/3;
    display: flex; flex-direction: column; align-items: center; justify-content: center;
    gap: 1rem; background: rgba(255,255,255,.03); color: var(--muted);
  }
  .camera-placeholder .cam-icon { font-size: 3rem; }
  .btn {
    padding: .7rem 1.5rem; border-radius: 12px; font-family: 'Cairo', sans-serif;
    font-size: .9rem; font-weight: 700; cursor: pointer; border: none;
    transition: all .2s;
  }
  .btn-start { background: linear-gradient(135deg, var(--accent), #8b5cf6); color: white; box-shadow: 0 4px 20px rgba(99,102,241,.4); }
  .btn-start:hover { transform: translateY(-2px); }
  .btn-stop { background: rgba(239,68,68,.15); color: #fca5a5; border: 1px solid rgba(239,68,68,.3); }
  .session-score { display: flex; align-items: center; gap: 1rem; padding: 1rem; background: rgba(99,102,241,.08); border: 1px solid rgba(99,102,241,.2); border-radius: 12px; margin-top: .5rem; }
  .score-emoji { font-size: 2rem; }
</style>
</head>
<body>
<div class="alert-toast" id="alertToast">
  ⚠️ <span id="alertText">انتبه! أنت غير مركّز</span>
</div>

<div class="top-bar">
  <a href="dashboard.php" class="back-btn">← الرجوع</a>
  <div class="lecture-title">📷 مراقبة التركيز — <?= htmlspecialchars($lecture['title']) ?></div>
  <div style="display:flex;align-items:center;gap:.6rem">
    <div style="width:8px;height:8px;background:var(--danger);border-radius:50%;animation:pulse 1.5s infinite"></div>
    <span style="font-size:.82rem">مراقبة نشطة</span>
  </div>
</div>

<div class="layout">
  <!-- Camera -->
  <div class="camera-panel">
    <div class="camera-box">
      <div class="camera-header">
        <h3>📷 الكاميرا المباشرة</h3>
        <div style="display:flex;gap:.6rem">
          <button class="btn btn-start" id="startBtn" onclick="startMonitoring()">▶ ابدأ المراقبة</button>
          <button class="btn btn-stop" id="stopBtn" onclick="stopMonitoring()" style="display:none">■ إيقاف</button>
        </div>
      </div>
      <div id="cameraContainer">
        <div class="camera-placeholder" id="placeholder">
          <div class="cam-icon">📷</div>
          <div>اضغط "ابدأ المراقبة" لتشغيل الكاميرا</div>
        </div>
        <video id="cameraFeed" autoplay muted playsinline style="display:none"></video>
        <canvas id="cameraCanvas"></canvas>
        <div class="camera-overlay" id="cameraOverlay" style="display:none">
          <div class="gaze-status">
            <div class="gaze-dot idle" id="gazeDot"></div>
            <span id="gazeText">جاري التحليل...</span>
          </div>
          <div class="confidence-pill" id="confidencePill">ثقة: —</div>
        </div>
      </div>
    </div>
  </div>

  <!-- Stats Panel -->
  <div class="stats-panel">
    <!-- Focus % -->
    <div class="stat-box">
      <h4>🎯 نسبة التركيز الكلية</h4>
      <div class="ring-wrap">
        <svg class="ring-svg" viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="40" fill="none" stroke="rgba(255,255,255,.08)" stroke-width="12"/>
          <circle cx="50" cy="50" r="40" fill="none" stroke="var(--success)" stroke-width="12"
            stroke-dasharray="251.2" id="ringFill" stroke-dashoffset="251.2"
            stroke-linecap="round" transform="rotate(-90 50 50)" style="transition:stroke-dashoffset 1s"/>
          <text x="50" y="50" text-anchor="middle" dominant-baseline="central"
            fill="white" font-family="Cairo" font-size="18" font-weight="900" id="ringText">0%</text>
        </svg>
        <div class="ring-stats">
          <div class="ring-stat"><span>مركّز</span><strong id="statFocused" style="color:var(--success)">0</strong></div>
          <div class="ring-stat"><span>غير مركّز</span><strong id="statDistracted" style="color:var(--danger)">0</strong></div>
          <div class="ring-stat"><span>لا وجه</span><strong id="statNoFace" style="color:var(--warning)">0</strong></div>
          <div class="ring-stat"><span>الإجمالي</span><strong id="statTotal">0</strong></div>
        </div>
      </div>
    </div>

    <!-- Timeline -->
    <div class="stat-box">
      <h4>📊 سجل التركيز (آخر 60 قراءة)</h4>
      <div class="timeline" id="timeline"></div>
      <div style="display:flex;gap:1rem;margin-top:.8rem;font-size:.72rem;color:var(--muted)">
        <span>🟢 مركّز</span><span>🔴 غير مركّز</span><span>🟡 لا وجه</span>
      </div>
    </div>

    <!-- Session Score -->
    <div class="stat-box" id="scoreBox" style="display:none">
      <h4>🏆 تقييم الجلسة</h4>
      <div class="session-score">
        <div class="score-emoji" id="scoreEmoji">—</div>
        <div>
          <div id="scoreLabel" style="font-size:1.2rem;font-weight:900">—</div>
          <div style="font-size:.78rem;color:var(--muted)" id="scoreDesc">—</div>
        </div>
      </div>
    </div>

    <!-- Instructions -->
    <div class="stat-box" id="instructionsBox">
      <h4>💡 تعليمات</h4>
      <div style="font-size:.82rem;color:var(--muted);line-height:1.8">
        ✅ وجّه الكاميرا ناحيتك<br>
        ✅ اضمن الإضاءة كويسة<br>
        ✅ ابقى منظور في الكاميرا<br>
        ❌ متبصش برا الشاشة كتير<br>
        ❌ متغطيش وشك
      </div>
    </div>
  </div>
</div>

<script>
const SESSION_ID = <?= $sessionId ?>;
const STUDENT_ID = <?= $user['id'] ?>;
const LECTURE_ID = <?= $lectureId ?>;
const API_URL = '../api/analyze_frame.php';
const INTERVAL_MS = <?= CAPTURE_INTERVAL_MS ?>;

let stream = null;
let intervalId = null;
let stats = { focused: 0, distracted: 0, noFace: 0, total: 0 };
let timeline = [];
let distractedStreak = 0;
let alertTimeout = null;

const video = document.getElementById('cameraFeed');
const canvas = document.getElementById('cameraCanvas');
const ctx = canvas.getContext('2d');

async function startMonitoring() {
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
    video.srcObject = stream;
    video.style.display = 'block';
    document.getElementById('placeholder').style.display = 'none';
    document.getElementById('cameraOverlay').style.display = 'flex';
    document.getElementById('startBtn').style.display = 'none';
    document.getElementById('stopBtn').style.display = 'inline-flex';
    document.getElementById('instructionsBox').style.display = 'none';

    // Start capturing
    intervalId = setInterval(captureAndAnalyze, INTERVAL_MS);
    captureAndAnalyze(); // immediate first capture
  } catch (err) {
    alert('تعذّر الوصول للكاميرا. تأكد من الصلاحيات.');
    console.error(err);
  }
}

function stopMonitoring() {
  if (intervalId) { clearInterval(intervalId); intervalId = null; }
  if (stream) { stream.getTracks().forEach(t => t.stop()); stream = null; }
  video.style.display = 'none';
  document.getElementById('placeholder').style.display = 'flex';
  document.getElementById('cameraOverlay').style.display = 'none';
  document.getElementById('startBtn').style.display = 'inline-flex';
  document.getElementById('stopBtn').style.display = 'none';
  showScore();
}

async function captureAndAnalyze() {
  if (!stream) return;
  canvas.width = video.videoWidth || 640;
  canvas.height = video.videoHeight || 480;
  ctx.drawImage(video, 0, 0);
  const imageData = canvas.toDataURL('image/jpeg', 0.7);

  try {
    const res = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        image: imageData,
        session_id: SESSION_ID,
        student_id: STUDENT_ID,
        lecture_id: LECTURE_ID
      })
    });
    const data = await res.json();
    if (data.error) return;
    updateUI(data);
    saveEvent(data);
  } catch (e) {
    console.error('Analysis error:', e);
  }
}

function updateUI(data) {
  const dot = document.getElementById('gazeDot');
  const gazeText = document.getElementById('gazeText');
  const confidencePill = document.getElementById('confidencePill');

  stats.total++;

  if (!data.face_detected) {
    dot.className = 'gaze-dot idle';
    gazeText.textContent = '⚪ لا يوجد وجه محدد';
    stats.noFace++;
    distractedStreak++;
    addTimeline('no-face');
  } else if (data.focused) {
    dot.className = 'gaze-dot focused';
    gazeText.textContent = '🟢 مركّز';
    stats.focused++;
    distractedStreak = 0;
    addTimeline('focused');
  } else {
    dot.className = 'gaze-dot distracted';
    gazeText.textContent = '🔴 غير مركّز';
    stats.distracted++;
    distractedStreak++;
    addTimeline('distracted');
  }

  confidencePill.textContent = `ثقة: ${data.confidence || 0}%`;

  // Alert after 3 consecutive distractions
  if (distractedStreak >= 3) {
    showAlert('⚠️ انتبه! ركّز في المحاضرة');
  }

  updateRingChart();
}

function addTimeline(type) {
  timeline.push(type);
  if (timeline.length > 60) timeline.shift();
  const container = document.getElementById('timeline');
  container.innerHTML = '';
  timeline.forEach(t => {
    const block = document.createElement('div');
    block.className = `tl-block ${t}`;
    container.appendChild(block);
  });
}

function updateRingChart() {
  const fp = stats.total > 0 ? (stats.focused / stats.total * 100) : 0;
  const circumference = 251.2;
  const offset = circumference - (fp / 100) * circumference;

  document.getElementById('ringFill').style.strokeDashoffset = offset;
  const color = fp >= 70 ? 'var(--success)' : fp >= 40 ? 'var(--warning)' : 'var(--danger)';
  document.getElementById('ringFill').style.stroke = color;
  document.getElementById('ringText').textContent = Math.round(fp) + '%';
  document.getElementById('statFocused').textContent = stats.focused;
  document.getElementById('statDistracted').textContent = stats.distracted;
  document.getElementById('statNoFace').textContent = stats.noFace;
  document.getElementById('statTotal').textContent = stats.total;
}

function showScore() {
  const fp = stats.total > 0 ? (stats.focused / stats.total * 100) : 0;
  let emoji, label, desc;
  if (fp >= 80) { emoji = '🌟'; label = 'ممتاز'; desc = 'أداء رائع! ركّزت معظم الوقت.'; }
  else if (fp >= 60) { emoji = '👍'; label = 'جيد'; desc = 'أداء كويس، حاول تحسينه.'; }
  else if (fp >= 40) { emoji = '😐'; label = 'مقبول'; desc = 'تركيزك متوسط، حاول أكتر.'; }
  else { emoji = '😟'; label = 'ضعيف'; desc = 'تركيزك منخفض، ركّز أكتر.'; }
  document.getElementById('scoreEmoji').textContent = emoji;
  document.getElementById('scoreLabel').textContent = label;
  document.getElementById('scoreDesc').textContent = desc;
  document.getElementById('scoreBox').style.display = 'block';
}

function showAlert(msg) {
  const toast = document.getElementById('alertToast');
  document.getElementById('alertText').textContent = msg;
  toast.classList.add('show');
  if (alertTimeout) clearTimeout(alertTimeout);
  alertTimeout = setTimeout(() => toast.classList.remove('show'), 4000);
}

async function saveEvent(data) {
  await fetch('../api/save_event.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      session_id: SESSION_ID,
      student_id: STUDENT_ID,
      lecture_id: LECTURE_ID,
      is_focused: data.focused ? 1 : 0,
      confidence: data.confidence || 0,
      label: data.label || '',
      face_detected: data.face_detected ? 1 : 0,
      stats: stats
    })
  });
}
</script>
</body>
</html>