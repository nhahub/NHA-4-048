<?php
require_once __DIR__ . '/includes/config.php';

if (isLoggedIn()) {
    header('Location: ' . ($_SESSION['role'] === 'teacher' ? 'teacher/dashboard.php' : 'student/dashboard.php'));
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $username  = trim($_POST['username'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $password  = $_POST['password'] ?? '';
    $confirm   = $_POST['confirm_password'] ?? '';
    $role      = $_POST['role'] ?? 'student';

    if (!$full_name || !$username || !$email || !$password) {
        $error = 'من فضلك ادخل كل البيانات المطلوبة';
    } elseif ($password !== $confirm) {
        $error = 'كلمتا المرور مش متطابقتين';
    } elseif (strlen($password) < 6) {
        $error = 'كلمة المرور لازم تكون 6 حروف على الأقل';
    } elseif (!in_array($role, ['student', 'teacher'])) {
        $error = 'نوع الحساب غلط';
    } else {
        $db = getDB();
        $check = $db->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $check->execute([$username, $email]);
        if ($check->fetch()) {
            $error = 'اسم المستخدم أو الإيميل موجود بالفعل';
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO users (full_name, username, email, password, role) VALUES (?,?,?,?,?)");
            $stmt->execute([$full_name, $username, $email, $hashed, $role]);
            $success = 'تم إنشاء الحساب بنجاح! يمكنك تسجيل الدخول الآن.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>إنشاء حساب — GazeTrack</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #0a0e1a; --card: #111827; --border: #1f2937;
    --accent: #6366f1; --accent2: #8b5cf6;
    --text: #f9fafb; --muted: #9ca3af;
    --success: #10b981; --danger: #ef4444;
  }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: 'Cairo', sans-serif; background: var(--bg); color: var(--text);
    min-height: 100vh; display: flex; align-items: center; justify-content: center;
    padding: 2rem 1rem;
  }
  body::before {
    content: ''; position: fixed; inset: 0;
    background: radial-gradient(ellipse 80% 60% at 20% 10%, rgba(99,102,241,.15) 0%, transparent 60%),
                radial-gradient(ellipse 60% 80% at 80% 90%, rgba(139,92,246,.12) 0%, transparent 60%);
    pointer-events: none;
  }
  .wrapper { width: 100%; max-width: 500px; position: relative; z-index: 1; }
  .back-link { display: inline-flex; align-items: center; gap: .4rem; color: var(--muted); text-decoration: none; font-size: .85rem; margin-bottom: 1.5rem; }
  .back-link:hover { color: var(--text); }
  .card { background: var(--card); border: 1px solid var(--border); border-radius: 24px; padding: 2.5rem; box-shadow: 0 25px 50px rgba(0,0,0,.5); }
  .card-header { text-align: center; margin-bottom: 2rem; }
  .card-header h2 { font-size: 1.6rem; font-weight: 900; }
  .card-header p { color: var(--muted); font-size: .9rem; margin-top: .3rem; }
  .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
  .form-group { margin-bottom: 1.2rem; }
  label { display: block; font-size: .85rem; font-weight: 600; color: var(--muted); margin-bottom: .5rem; }
  input, select {
    width: 100%; background: rgba(255,255,255,.05); border: 1px solid var(--border);
    border-radius: 12px; padding: .85rem 1.1rem; color: var(--text);
    font-family: 'Cairo', sans-serif; font-size: .95rem; outline: none;
    transition: border-color .2s, box-shadow .2s; direction: rtl;
  }
  input:focus, select:focus { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(99,102,241,.2); }
  select option { background: #1f2937; }
  .role-toggle { display: grid; grid-template-columns: 1fr 1fr; gap: .7rem; margin-bottom: 1.2rem; }
  .role-option { display: none; }
  .role-label {
    display: flex; flex-direction: column; align-items: center; gap: .3rem;
    padding: 1rem; border: 2px solid var(--border); border-radius: 14px;
    cursor: pointer; transition: all .2s; font-size: .85rem;
  }
  .role-label .role-icon { font-size: 1.8rem; }
  .role-option:checked + .role-label { border-color: var(--accent); background: rgba(99,102,241,.1); color: var(--accent); }
  .alert { border-radius: 10px; padding: .8rem 1rem; font-size: .88rem; margin-bottom: 1.4rem; display: flex; align-items: center; gap: .5rem; }
  .alert-error { background: rgba(239,68,68,.1); border: 1px solid rgba(239,68,68,.3); color: #fca5a5; }
  .alert-success { background: rgba(16,185,129,.1); border: 1px solid rgba(16,185,129,.3); color: #6ee7b7; }
  .btn-submit {
    width: 100%; background: linear-gradient(135deg, var(--accent), var(--accent2));
    color: white; border: none; border-radius: 12px; padding: .95rem;
    font-family: 'Cairo', sans-serif; font-size: 1rem; font-weight: 700;
    cursor: pointer; transition: transform .2s, box-shadow .2s;
    box-shadow: 0 4px 20px rgba(99,102,241,.4);
  }
  .btn-submit:hover { transform: translateY(-2px); box-shadow: 0 8px 30px rgba(99,102,241,.5); }
  .login-link { text-align: center; margin-top: 1.2rem; font-size: .85rem; color: var(--muted); }
  .login-link a { color: var(--accent); text-decoration: none; font-weight: 600; }
</style>
</head>
<body>
<div class="wrapper">
  <a href="login.php" class="back-link">← رجوع لتسجيل الدخول</a>
  <div class="card">
    <div class="card-header">
      <h2>👁️ إنشاء حساب جديد</h2>
      <p>انضم لنظام GazeTrack</p>
    </div>
    <?php if ($error): ?><div class="alert alert-error">⚠️ <?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success">✅ <?= htmlspecialchars($success) ?> <a href="login.php" style="color:inherit;font-weight:700">سجّل الدخول</a></div><?php endif; ?>
    <?php if (!$success): ?>
    <form method="POST">
      <div class="form-group">
        <label>نوع الحساب</label>
        <div class="role-toggle">
          <input type="radio" name="role" id="role_student" value="student" class="role-option" checked>
          <label for="role_student" class="role-label"><span class="role-icon">👨‍🎓</span>طالب</label>
          <input type="radio" name="role" id="role_teacher" value="teacher" class="role-option">
          <label for="role_teacher" class="role-label"><span class="role-icon">🧑‍🏫</span>مدرس</label>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>الاسم الكامل</label>
          <input type="text" name="full_name" placeholder="اسمك بالكامل" required>
        </div>
        <div class="form-group">
          <label>اسم المستخدم</label>
          <input type="text" name="username" placeholder="username" required>
        </div>
      </div>
      <div class="form-group">
        <label>البريد الإلكتروني</label>
        <input type="email" name="email" placeholder="example@email.com" required>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>كلمة المرور</label>
          <input type="password" name="password" placeholder="••••••••" required minlength="6">
        </div>
        <div class="form-group">
          <label>تأكيد كلمة المرور</label>
          <input type="password" name="confirm_password" placeholder="••••••••" required>
        </div>
      </div>
      <button type="submit" class="btn-submit">إنشاء الحساب</button>
    </form>
    <?php endif; ?>
    <div class="login-link">عندك حساب بالفعل؟ <a href="login.php">سجّل دخولك</a></div>
  </div>
</div>
</body>
</html>