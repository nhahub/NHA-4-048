<?php

session_start();

require_once __DIR__ . '/includes/config.php';

if (isset($_SESSION['user_id'])) {

    if ($_SESSION['role'] === 'teacher') {
        header("Location: teacher/dashboard.php");
    } else {
        header("Location: student/dashboard.php");
    }

    exit;
}

$error = '';
$debug = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    try {

        $db = getDB();

        $stmt = $db->prepare("
            SELECT * FROM users
            WHERE username = ?
            LIMIT 1
        ");

        $stmt->execute([$username]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {

            $error = "❌ Username not found";

        } else {

            $debug .= "User Found ✅<br>";
            $debug .= "DB Username: " . $user['username'] . "<br>";
            $debug .= "Role: " . $user['role'] . "<br>";

            if (password_verify($password, $user['password'])) {

                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['role'] = $user['role'];

                $db->prepare("
                    UPDATE users
                    SET last_login = NOW()
                    WHERE id = ?
                ")->execute([$user['id']]);

                if ($user['role'] === 'teacher') {

                    header("Location: teacher/dashboard.php");

                } else {

                    header("Location: student/dashboard.php");
                }

                exit;

            } else {

                $error = "❌ Password incorrect";
            }
        }

    } catch (PDOException $e) {

        $error = $e->getMessage();
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>GazeTrack Login</title>

<style>

body{
    margin:0;
    padding:0;
    background:#0f172a;
    font-family:Arial;
    color:white;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

.card{
    width:400px;
    background:#111827;
    padding:30px;
    border-radius:20px;
    box-shadow:0 0 25px rgba(0,0,0,.4);
}

h1{
    text-align:center;
    margin-bottom:25px;
}

input{
    width:100%;
    padding:14px;
    margin-top:12px;
    border:none;
    border-radius:10px;
    background:#1e293b;
    color:white;
    font-size:15px;
}

button{
    width:100%;
    padding:14px;
    margin-top:20px;
    border:none;
    border-radius:10px;
    background:#6366f1;
    color:white;
    font-size:16px;
    cursor:pointer;
}

button:hover{
    background:#4f46e5;
}

.error{
    background:#7f1d1d;
    padding:12px;
    border-radius:10px;
    margin-top:15px;
}

.debug{
    background:#1e293b;
    padding:12px;
    border-radius:10px;
    margin-top:15px;
    font-size:13px;
}

.demo{
    margin-top:20px;
    background:#0f172a;
    padding:12px;
    border-radius:10px;
    font-size:14px;
}

</style>

</head>

<body>

<div class="card">

<h1>👁️ GazeTrack</h1>

<form method="POST">

<input
    type="text"
    name="username"
    placeholder="Username"
    required
>

<input
    type="password"
    name="password"
    placeholder="Password"
    required
>

<button type="submit">
    LOGIN
</button>

</form>

<?php if($error): ?>

<div class="error">

<?= $error ?>

</div>

<?php endif; ?>

<?php if($debug): ?>

<div class="debug">

<?= $debug ?>

</div>

<?php endif; ?>

<div class="demo">

<b>Demo Accounts:</b><br><br>

Teacher:<br>
Username: dr_ahmed<br>
Password: password<br><br>

Student:<br>
Username: student1<br>
Password: password

</div>

</div>

</body>
</html>