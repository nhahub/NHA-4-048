<?php
require_once __DIR__ . '/includes/config.php';
if (isLoggedIn()) {
    header('Location: ' . ($_SESSION['role'] === 'teacher' ? 'teacher/dashboard.php' : 'student/dashboard.php'));
} else {
    header('Location: login.php');
}