<?php
// create_lecture.php
require_once __DIR__ . '/../includes/config.php';
requireRole('teacher');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: dashboard.php'); exit;
}

$title       = trim($_POST['title'] ?? '');
$subject     = trim($_POST['subject'] ?? '');
$description = trim($_POST['description'] ?? '');
$scheduled   = $_POST['scheduled_at'] ?? null;

if (!$title) {
    header('Location: dashboard.php?error=no_title'); exit;
}

$db = getDB();

// Generate unique 6-char code
do {
    $code = strtoupper(substr(md5(uniqid()), 0, 6));
    $exists = $db->prepare("SELECT id FROM lectures WHERE access_code = ?");
    $exists->execute([$code]);
} while ($exists->fetch());

$db->prepare("
    INSERT INTO lectures (teacher_id, title, subject, description, scheduled_at, access_code)
    VALUES (?,?,?,?,?,?)
")->execute([
    $_SESSION['user_id'], $title, $subject ?: null,
    $description ?: null, $scheduled ?: null, $code
]);

header('Location: dashboard.php?success=created');