<?php
require_once __DIR__ . '/../includes/config.php';
requireRole('teacher');
$user = getCurrentUser();
$db = getDB();

$lectureId = intval($_GET['id'] ?? 0);
$lecture = $db->prepare("SELECT * FROM lectures WHERE id = ? AND teacher_id = ?");
$lecture->execute([$lectureId, $user['id']]);
$lecture = $lecture->fetch();
if (!$lecture) { header('Location: dashboard.php'); exit; }

// Student results
$students = $db->prepare("
    SELECT u.full_name, u.username,
           ms.focus_percentage, ms.focused_frames, ms.total_frames,
           ms.distracted_frames, ms.no_face_frames, ms.final_score,
           ms.started_at, ms.ended_at
    FROM monitoring_sessions ms
    JOIN users u ON ms.student_id = u.id
    WHERE ms.lecture_id = ?
    ORDER BY ms.focus_percentage DESC
");
$students->execute([$lectureId]);
$students = $students->fetchAll();

$avgFocus = $students ? array_sum(array_column($students, 'focus_percentage')) / count($students) : 0;
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<title>تقرير المحاضرة — GazeTrack</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap" rel="stylesheet">
<style>
  :root { --bg:#0a0e1a;--card:#111827;--border:#1f2937;--accent:#6366f1;--text:#f9fafb;--muted:#9ca3af;--success:#10b981;--warning:#f59e0b;--danger:#ef4444; }
  *{margin:0;padding:0;box-sizing:border-box}
  body{font-family:'Cairo',sans-serif;background:var(--bg);color:var(--text);padding:2rem}
  .header{margin-bottom:2rem;display:flex;align-items:center;gap:1rem}
  a.back{background:rgba(255,255,255,.07);border:1px solid var(--border);color:var(--text);padding:.4rem .8rem;border-radius:8px;text-decoration:none;font-size:.82rem}
  h1{font-size:1.5rem;font-weight:900}
  .overview{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin-bottom:2rem}
  .ov{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:1.2rem;text-align:center}
  .ov-val{font-size:2rem;font-weight:900}
  .ov-lbl{font-size:.78rem;color:var(--muted);margin-top:.2rem}
  .card{background:var(--card);border:1px solid var(--border);border-radius:16px;overflow:hidden}
  table{width:100%;border-collapse:collapse}
  th{font-size:.78rem;color:var(--muted);font-weight:600;text-align:right;padding:.7rem 1rem;border-bottom:1px solid var(--border)}
  td{padding:.9rem 1rem;border-bottom:1px solid rgba(255,255,255,.04);font-size:.85rem;vertical-align:middle}
  tr:last-child td{border-bottom:none}
  .bar{height:8px;background:rgba(255,255,255,.08);border-radius:4px;overflow:hidden;min-width:80px}
  .bar-fill{height:100%;border-radius:4px}
  .badge{display:inline-flex;padding:.22rem .6rem;border-radius:20px;font-size:.72rem;font-weight:700}
  .score-excellent{background:rgba(16,185,129,.15);color:#6ee7b7}
  .score-good{background:rgba(59,130,246,.15);color:#93c5fd}
  .score-average{background:rgba(245,158,11,.15);color:#fcd34d}
  .score-poor{background:rgba(239,68,68,.15);color:#fca5a5}
</style>
</head>
<body>
<div class="header">
  <a href="dashboard.php" class="back">← رجوع</a>
  <div>
    <h1>📊 تقرير: <?= htmlspecialchars($lecture['title']) ?></h1>
    <div style="font-size:.82rem;color:var(--muted)">كود: <?= $lecture['access_code'] ?> • <?= count($students) ?> طالب</div>
  </div>
</div>

<div class="overview">
  <div class="ov"><div class="ov-val"><?= count($students) ?></div><div class="ov-lbl">طلاب شاركوا</div></div>
  <div class="ov"><div class="ov-val" style="color:var(--success)"><?= round($avgFocus,1) ?>%</div><div class="ov-lbl">متوسط التركيز</div></div>
  <div class="ov"><div class="ov-val" style="color:var(--success)"><?= count(array_filter($students, fn($s)=>$s['focus_percentage']>=60)) ?></div><div class="ov-lbl">تركيز جيد فأعلى</div></div>
  <div class="ov"><div class="ov-val" style="color:var(--danger)"><?= count(array_filter($students, fn($s)=>$s['focus_percentage']<40)) ?></div><div class="ov-lbl">تركيز ضعيف</div></div>
</div>

<div class="card">
  <table>
    <thead>
      <tr>
        <th>#</th><th>الطالب</th><th>التركيز</th><th>مركّز</th><th>متشتت</th><th>الإجمالي</th><th>التقييم</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($students as $i => $s): ?>
      <?php $fp = round($s['focus_percentage'],1); ?>
      <tr>
        <td style="color:var(--muted)"><?= $i+1 ?></td>
        <td><strong><?= htmlspecialchars($s['full_name']) ?></strong><div style="font-size:.72rem;color:var(--muted)">@<?= $s['username'] ?></div></td>
        <td>
          <div style="display:flex;align-items:center;gap:.6rem">
            <div class="bar"><div class="bar-fill" style="width:<?= $fp ?>%;background:<?= $fp>=70?'var(--success)':($fp>=40?'var(--warning)':'var(--danger)') ?>"></div></div>
            <span><?= $fp ?>%</span>
          </div>
        </td>
        <td style="color:var(--success)"><?= $s['focused_frames'] ?></td>
        <td style="color:var(--danger)"><?= $s['distracted_frames'] ?></td>
        <td><?= $s['total_frames'] ?></td>
        <td><span class="badge score-<?= $s['final_score'] ?>"><?= scoreLabel($s['final_score']) ?></span></td>
      </tr>
      <?php endforeach; ?>
      <?php if(empty($students)): ?>
      <tr><td colspan="7" style="text-align:center;padding:3rem;color:var(--muted)">لا توجد بيانات بعد</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
</body>
</html>